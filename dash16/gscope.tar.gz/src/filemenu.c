#include <gtk/gtk.h>

#include "filemenu.h"

void gscope_menu_file_exit(GtkWidget *widget, gpointer data)
{
  /* Any dialog boxes go here */

  gtk_exit(0);
}

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <gtk/gtk.h>

#define RC_BUF_SIZE 512

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MAIN_H */

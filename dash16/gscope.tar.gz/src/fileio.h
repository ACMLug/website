#ifndef __FILEIO_H
#define __FILEIO_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <gtk/gtk.h>

  void gscope_add_items(GtkWidget*);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MAIN_H */

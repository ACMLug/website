#ifndef __GTK_OSCILLISCOPE_H__
#define __GTK_OSCILLISCOPE_H__

#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>

#define OSCILLISCOPE_DEFAULT_WIDTH  100
#define OSCILLISCOPE_DEFAULT_HEIGHT 100

#define GTK_OSCILLISCOPE(obj)         GTK_CHECK_CAST(obj, gscope_get_type(), GtkOscilliscope)
#define GTK_OSCILLISCOPE_CLASS(class) GTK_CHECK_CLASS_CAST(class, gscope_get_type(), GtkOscilliscopeClass)
#define GTK_IS_OSCILLISCOPE(obj)      GTK_CHECK_TYPE(obj, gscope_get_type())

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  typedef struct _GtkOscilliscope {
    GtkWidget widget;
    guint     policy : 2;

    guint8    button;
    guint32   timer;

    gfloat    maxValue;
    gfloat    minValue;
    gfloat    centerValue;

    gboolean  visibleGridlines;
    gboolean  visibleZeroLine;
    gboolean  visibleLabels;

    guint     dataArraySize;
    guint     numItemsOffScreen;
    gfloat*   offScreenDataArray;
    gfloat*   onScreenDataArray;
/*
    gboolean  triggerReady;
    gfloat    trigger;
    guint     numFailures; */
  } GtkOscilliscope;

  typedef struct _GtkOscilliscopeClass {
    GtkWidgetClass parent_class;
  } GtkOscilliscopeClass;

  GtkWidget* gscope_new                  (void);
  guint      gscope_get_type             (void);
  void       gscope_set_update_policy    (GtkOscilliscope*, GtkUpdateType);
  gint       gscope_add_float            (GtkOscilliscope*, gfloat);
  gint       gscope_add_floats           (GtkOscilliscope*, gfloat[], gint);
  void       gscope_set_maxnumitems      (GtkOscilliscope*, guint);
  void       gscope_set_limits           (GtkOscilliscope*, gfloat, gfloat);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __GTK_OSCILLISCOPE_H__ */

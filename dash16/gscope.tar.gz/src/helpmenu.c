#include <gtk/gtk.h>

#include "helpmenu.h"
#include "config.h"
#include "pixmaps/acm.xpm"

#define ABOUT_TEXT_LENGTH 512

void gscope_about_close(GtkWidget* widget, gpointer data)
{
  if (GTK_IS_WIDGET(data)) {
    gtk_widget_destroy(GTK_WIDGET(data));
  }
}

void gscope_menu_help_about(GtkWidget *widget, gpointer data)
{
  GtkWidget* window;
  GtkWidget* vbox;
  GtkWidget* acmlogow;
  GtkWidget* aboutLabel;
  GtkWidget* creditsLabel;
  GtkWidget* bbox;
  GtkWidget* button;
  GdkPixmap* acmlogo;
  GdkBitmap* mask;
  gchar      aboutText[ABOUT_TEXT_LENGTH];

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect(GTK_OBJECT(window), "destroy",
                     GTK_SIGNAL_FUNC(gscope_about_close), NULL);
  gtk_window_set_title(GTK_WINDOW(window), "About gscope");
  gtk_widget_set_usize(GTK_WIDGET(window), 400, 300);
  
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_set_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(window), vbox);

  gtk_widget_realize(window);

  acmlogo = gdk_pixmap_create_from_xpm_d(window->window, &mask,
                                     &window->style->white, acm_xpm);
  acmlogow = gtk_pixmap_new(acmlogo, mask);

  gtk_box_pack_start(GTK_BOX(vbox), acmlogow, TRUE, FALSE, 0);

  g_snprintf(aboutText, ABOUT_TEXT_LENGTH, "GScope version %s", VERSION);
  aboutLabel = gtk_label_new(aboutText);
  gtk_box_pack_start(GTK_BOX(vbox), aboutLabel, TRUE, FALSE, 0);

  creditsLabel = gtk_label_new("GScope was written by Steven Engelhardt,\nSean O'Connor and Mike Perry");
  gtk_box_pack_start(GTK_BOX(vbox), creditsLabel, TRUE, FALSE, 0);

  bbox = gtk_hbutton_box_new();
  gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 0);
  gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox), GTK_BUTTONBOX_DEFAULT_STYLE);

  button = gtk_button_new_with_label("OK");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gscope_about_close), window);
  gtk_container_add(GTK_CONTAINER(bbox), button);
  GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
  gtk_widget_grab_default(button);

  gtk_widget_show_all(window);
}

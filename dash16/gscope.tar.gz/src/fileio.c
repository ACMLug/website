#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <gtk/gtk.h>

#define READ 32

#include "gtkoscilliscope.h"
#include "fileio.h"

#define GSCOPE_DATA_SOURCE "/home/lug/dash-16/dash16"

int fd;
void gscope_add_items(GtkWidget* widget)
{
  FILE *fp;
  gshort  temp[READ];
  gfloat  temp2[READ];
  guint i;

  g_return_if_fail(GTK_IS_OSCILLISCOPE(widget));

  fd = open(GSCOPE_DATA_SOURCE, O_RDONLY);
  fp = fdopen(fd, "r");

  
  fread(temp, sizeof(gshort), READ, fp);
  while(1) {

    for (i = 0; i < READ; i++) {
      /* convert all the shorts to floats */
     temp[i] >>= 4;
     if(temp[i] < 0)
	temp[i] += 2048;
     else
	temp[i] -= 2048;

     temp2[i] = (gfloat) ((gshort)temp[i])/ 10000.0; 
      /* g_print("temp2[i] = %f\n", temp2[i]); */

    }

    gscope_add_floats(GTK_OSCILLISCOPE(widget), temp2, READ);

    fread(temp, sizeof(gshort), READ, fp);

    if (gtk_events_pending()) {
      gtk_main_iteration();
    }
  }

  fclose(fp);
}


#ifndef __HELPMENU_H__
#define __HELPMENU_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdio.h>
#include <gtk/gtk.h>

  void gscope_menu_help_about(GtkWidget*, gpointer);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

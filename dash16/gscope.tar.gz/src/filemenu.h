#ifndef __FILEMENU_H__
#define __FILEMENU_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdio.h>
#include <gtk/gtk.h>

  void gscope_menu_file_exit(GtkWidget*, gpointer);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

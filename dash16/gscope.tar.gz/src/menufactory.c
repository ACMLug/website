#include <gtk/gtkmenuitem.h>
#include <gtk/gtk.h>

#include "filemenu.h"
#include "helpmenu.h"

static GtkItemFactoryEntry gscope_menu_items[] =
{
  {"/_File",       NULL, NULL,                   0, "<Branch>"},
  {"/File/E_xit",  "<control>Q", gscope_menu_file_exit,  0, NULL},
  {"/_Help",       NULL, NULL,                   0, "<LastBranch>"},
  {"/Help/_About", NULL, gscope_menu_help_about, 0, NULL}
};

void gscope_get_main_menu(GtkWidget *window, GtkWidget ** menubar)
{
  GtkItemFactory* factory;
  GtkAccelGroup*  accel;
  GtkWidget*      w;
  gint nmenu_items = sizeof(gscope_menu_items) / sizeof(gscope_menu_items[0]);

  accel   = gtk_accel_group_new();
  factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>", accel);

  gtk_item_factory_create_items(factory, nmenu_items, gscope_menu_items, NULL);
  gtk_accel_group_attach(accel, GTK_OBJECT(window));
  w = gtk_item_factory_get_widget(factory, "/Help/About");
  gtk_menu_item_right_justify(GTK_MENU_ITEM(w));

  if (menubar) {
    *menubar = gtk_item_factory_get_widget(factory, "<main>");
  }
}

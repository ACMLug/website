#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "dash16.h"

// 2.44 milivolts per bit
#define VOLTS_BIT .000625
#define ZERO	0.75
extern int errno;
int filedes;
#define name "dash16"
int poop;

void main(int argc, char **argv)
{
  struct dash16_timer_regs regs = {{0,0,0},0};  
  struct dash16_channel_range channels;
  u8 status;
  short result;
  int filedes = 0;
  int zeros = 0;
  int i = 0;
  short *buf;
  int howmuch;

  if (argc != 2) 
  {
    printf("Fix the arguments, please.\n");
    exit(0);
  }

  howmuch = atoi(argv[1]);

  buf =(short *)malloc(sizeof(short)*howmuch);

  if (-1 == (filedes = open(name, O_RDWR))) 
  {
    perror("Error opening file:");
  }
  else printf("File number is %d\n", filedes);
  
  channels.start = 0;
  channels.end = 0;

  ioctl(filedes, DASH16_CHANNELS_SELECT, &channels);

  ioctl(filedes, DASH16_READ_STATUS, &i);

  printf("Stauts 0x%x\n", i);

  ioctl(filedes, DASH16_READ_CONTROL, &i);

  printf("CONTROL 0x%x\n", i);

  while (0)
  {
    ioctl(filedes, DASH16_TIMER_CTLR_RAW, &regs);

    printf("ctr0 0x%x ctr1 0x%x ctr2 0x%x\n", 
         regs.ctr[0], regs.ctr[1], regs.ctr[2]);
    usleep(10);
  }

  if(read(filedes, buf, howmuch*sizeof(short)) == -1)
    perror("Error in read: ");

  printf("After read\n");

  for(i = 0; i < howmuch; i++) {
     result = (buf[i] >> 4);
     if(result == 0)
	zeros++;
     printf("result = %5d\n", result);
     if(!(i % 4))
	puts("");
  }
  printf("Read %d zeros. (That's %d bytes\n", zeros, zeros*sizeof(short));

 puts("\n");

  fflush(stdin);

  if(errno)
  {
    printf("%d\n", errno);
    perror("Error: ");
  }

  close(filedes);

}

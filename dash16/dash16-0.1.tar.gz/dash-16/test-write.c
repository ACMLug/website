#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "dash16.h"

// 2.44 milivolts per bit
#define VOLTS_BIT .000625
#define ZERO	0.75
extern int errno;
int filedes;
#define name "dash16"
int poop;

void main(int argc, char **argv)
{
  int filedes = 0;
  int i = 0;
  short *buf;
  int howmuch;
  FILE *fp;

  if (argc != 3) 
  {
    printf("Usage: %s filename howmuch\n", argv[0]);
    exit(0);
  }

  howmuch = atoi(argv[2]);

  if((fp = fopen(argv[1], "r")) == NULL)
  {
    printf("Error opening filename %s\n", argv[1]);
  }

  
  buf =(short *)malloc(sizeof(short)*howmuch);

  fread(buf, howmuch, 1, fp);

  fclose(fp);

  if (-1 == (filedes = open(name, O_RDWR))) 
  {
    perror("Error opening file:");
  }

  for (i = 0; i < howmuch/sizeof(short); i++)
  {
    buf[i] <<= 4;
  }
  
  if(write(filedes, buf, howmuch) == -1)
    perror("Error in read: ");

  fflush(stdin);

  if(errno)
  {
    printf("%d\n", errno);
    perror("Error: ");
  }

  close(filedes);

}

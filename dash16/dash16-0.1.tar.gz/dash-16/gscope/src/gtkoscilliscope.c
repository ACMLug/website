#include <math.h>
#include <unistd.h>
#include <gtk/gtkmain.h>
#include <gtk/gtksignal.h>

#include "gtkoscilliscope.h"

static void gscope_init          (GtkOscilliscope*);
static void gscope_class_init    (GtkOscilliscopeClass*);
static void gscope_destroy       (GtkObject*);
static void gscope_realize       (GtkWidget*);
static gint gscope_expose        (GtkWidget*, GdkEventExpose*);
static void gscope_size_request  (GtkWidget*, GtkRequisition*);
static void gscope_size_allocate (GtkWidget*, GtkAllocation*);
static gint gscope_button_press  (GtkWidget*, GdkEventButton*);
static gint gscope_button_release(GtkWidget*, GdkEventButton*);
static void gscope_update_mouse  (GtkOscilliscope*, gint, gint);

static GtkWidget* parent_class = NULL;

static void gscope_update_mouse(GtkOscilliscope* scope, gint x, gint y)
{
  g_print("x: %i, y: %i\n", x, y);
}

static gint gscope_button_release(GtkWidget* widget, GdkEventButton* event)
{
  GtkOscilliscope* scope;

  scope = GTK_OSCILLISCOPE(widget);

  if (scope->button == event->button) {
    gtk_grab_remove(widget);
    scope->button = 0;
  }

  g_print("gscope_button_release\n");

  return FALSE;
}

static gint gscope_button_press(GtkWidget* widget, GdkEventButton* event)
{
  GtkOscilliscope* scope;
  gfloat zeroLinePos;
  gfloat dy;

  scope = GTK_OSCILLISCOPE(widget);

  zeroLinePos = widget->allocation.height *
    scope->maxValue / (scope->maxValue - scope->minValue);

  dy = fabs(zeroLinePos - event->y);

  if (dy < 5.0) {
    gtk_grab_add(widget);
    scope->button = event->button;
    gscope_update_mouse(scope, event->x, event->y);
  }

  return FALSE;
}

static void gscope_realize(GtkWidget* widget)
{
  GtkOscilliscope* oscilliscope;
  GdkWindowAttr    attributes;
  gint             attributes_mask;

  g_return_if_fail(widget != NULL);
  g_return_if_fail(GTK_IS_OSCILLISCOPE(widget));

  GTK_WIDGET_SET_FLAGS(widget, GTK_REALIZED);
  oscilliscope = GTK_OSCILLISCOPE(widget);

  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.event_mask = gtk_widget_get_events(widget)
    | GDK_EXPOSURE_MASK
    | GDK_BUTTON_PRESS_MASK
    | GDK_BUTTON_RELEASE_MASK;
  attributes.visual = gtk_widget_get_visual(widget);
  attributes.colormap = gtk_widget_get_colormap(widget);

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
  widget->window = gdk_window_new(widget->parent->window, &attributes,
                                  attributes_mask);
  widget->style = gtk_style_attach(widget->style, widget->window);
  gdk_window_set_user_data(widget->window, widget);
  gtk_style_set_background(widget->style, widget->window, GTK_STATE_NORMAL);
}

static gint gscope_expose(GtkWidget* widget, GdkEventExpose* event)
{
  GtkOscilliscope* oscilliscope;
  guint            width, height, center;
  gfloat           minValue, maxValue, centerValue;
  guint            i;
  gfloat           j;
  gchar            maxLabelText[5];
  gint             maxLabelTextHeight, maxLabelTextWidth;
  gchar            minLabelText[5];
  gint             minLabelTextHeight, minLabelTextWidth;
  gchar            centerLabelText[5];
  gint             centerLabelTextHeight, centerLabelTextWidth;

  g_return_val_if_fail(widget != NULL, FALSE);
  g_return_val_if_fail(GTK_IS_OSCILLISCOPE(widget), FALSE);
  g_return_val_if_fail(event != NULL, FALSE);

  if (event->count > 0) {
    return FALSE;
  }

  oscilliscope = GTK_OSCILLISCOPE(widget);
  minValue     = oscilliscope->minValue;
  maxValue     = oscilliscope->maxValue;
  centerValue  = oscilliscope->centerValue;
  width        = widget->allocation.width;
  height       = widget->allocation.height;
  center       = height / 2;

  gdk_window_clear_area(widget->window, 0, 0, width, height);

  if (oscilliscope->visibleGridlines) {
    for (j = minValue; j < maxValue; j += (maxValue - minValue) / 8.0) {
      gfloat b = height * maxValue / (maxValue - minValue);
      gfloat m = height / (minValue - maxValue);     
      gdk_draw_line(widget->window,
                    widget->style->fg_gc[GTK_STATE_INSENSITIVE],
                    0, m * j + b, width, m * j + b);
    }
    
    for (i = 0; i < width; i += width / 8) {
      gdk_draw_line(widget->window,
                    widget->style->fg_gc[GTK_STATE_INSENSITIVE],
                    i, 0, i, height);
    }
  }

  if (oscilliscope->visibleZeroLine) {
    gfloat b = height * maxValue / (maxValue - minValue);
    gdk_draw_line(widget->window, widget->style->fg_gc[GTK_STATE_PRELIGHT],
                  0, b, width, b);
  }

  if (oscilliscope->visibleLabels) {
    g_snprintf(maxLabelText, 5, "%0.1f", maxValue);
    maxLabelTextHeight = gdk_string_height(widget->style->font, maxLabelText);
    maxLabelTextWidth  = gdk_string_width(widget->style->font, maxLabelText);
    
    g_snprintf(minLabelText, 5, "%0.1f", minValue);
    minLabelTextHeight = gdk_string_height(widget->style->font, minLabelText);
    minLabelTextWidth  = gdk_string_width(widget->style->font, minLabelText);
    
    g_snprintf(centerLabelText, 5, "%0.1f", centerValue);
    centerLabelTextHeight = gdk_string_height(widget->style->font,
                                              centerLabelText);
    centerLabelTextWidth  = gdk_string_width(widget->style->font,
                                             centerLabelText);

    gdk_draw_string(widget->window, widget->style->font,
                    widget->style->white_gc, 2,
                    maxLabelTextHeight + 2, maxLabelText);
    gdk_draw_string(widget->window, widget->style->font,
                    widget->style->white_gc, 2,
                    height - 2, minLabelText);
    gdk_draw_string(widget->window, widget->style->font,
                    widget->style->white_gc, 2,
                    center + centerLabelTextHeight / 2, centerLabelText);
  }

  for (i = 1; i < oscilliscope->dataArraySize; i++) {
    gfloat x_b = width / (gfloat) oscilliscope->dataArraySize;
    gfloat y_b = height * maxValue / (maxValue - minValue);
    gfloat y_m = height / (minValue - maxValue);

    gdk_draw_line(widget->window, widget->style->fg_gc[widget->state],
                  x_b * (gfloat) (i - 1),
                  y_m * oscilliscope->onScreenDataArray[i - 1] + y_b,
                  x_b * (gfloat) i,
                  y_m * oscilliscope->onScreenDataArray[i] + y_b);
  }

  return FALSE;
}

static void gscope_init(GtkOscilliscope* oscilliscope)
{
  guint i;

  g_return_if_fail(oscilliscope != NULL);

  oscilliscope->policy             = GTK_UPDATE_DELAYED;
  oscilliscope->maxValue           = 1.5;
  oscilliscope->minValue           = -1.5;
  oscilliscope->centerValue        = 0.0;
  oscilliscope->visibleGridlines   = TRUE;
  oscilliscope->visibleZeroLine    = TRUE;
  oscilliscope->visibleLabels      = TRUE;
  oscilliscope->dataArraySize      = OSCILLISCOPE_DEFAULT_WIDTH;
  oscilliscope->numItemsOffScreen  = 0;
  /*oscilliscope->triggerReady       = FALSE;
  oscilliscope->trigger            = 0.0;
  oscilliscope->numFailures        = 0;*/
  oscilliscope->onScreenDataArray  = g_malloc(sizeof(gfloat) *
                                              oscilliscope->dataArraySize);
  oscilliscope->offScreenDataArray = g_malloc(sizeof(gfloat) *
                                              oscilliscope->dataArraySize);

  g_return_if_fail(oscilliscope->onScreenDataArray != NULL);
  g_return_if_fail(oscilliscope->offScreenDataArray != NULL);

  for (i = 0; i < oscilliscope->dataArraySize; i++) {
    oscilliscope->onScreenDataArray[i] = 0.0;
    oscilliscope->offScreenDataArray[i] = 0.0;
  }
}

static void gscope_class_init(GtkOscilliscopeClass* class)
{
  GtkObjectClass* object_class;
  GtkWidgetClass* widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class(gtk_widget_get_type());

  object_class->destroy = gscope_destroy;

  widget_class->realize              = gscope_realize;
  widget_class->expose_event         = gscope_expose;
  widget_class->size_request         = gscope_size_request;
  widget_class->size_allocate        = gscope_size_allocate;
  widget_class->button_press_event   = gscope_button_press;
  widget_class->button_release_event = gscope_button_release;
  widget_class->motion_notify_event  = NULL;
}

static void gscope_destroy(GtkObject* object)
{
  GtkOscilliscope* oscilliscope;

  g_return_if_fail(object != NULL);
  g_return_if_fail(GTK_IS_OSCILLISCOPE(object));

  oscilliscope = GTK_OSCILLISCOPE(object);

  g_free(oscilliscope->onScreenDataArray);
  g_free(oscilliscope->offScreenDataArray);

  if (GTK_OBJECT_CLASS(parent_class)->destroy) {
    (*GTK_OBJECT_CLASS(parent_class)->destroy)(object);
  }
}

static void gscope_size_request(GtkWidget* widget,
                                GtkRequisition* req)
{
  req->width  = OSCILLISCOPE_DEFAULT_WIDTH;
  req->height = OSCILLISCOPE_DEFAULT_HEIGHT;
}

static void gscope_size_allocate(GtkWidget* widget,
                                 GtkAllocation* alloc)
{
  GtkOscilliscope* oscilliscope;
  guint i;

  g_return_if_fail(widget != NULL);
  g_return_if_fail(GTK_IS_OSCILLISCOPE(widget));
  g_return_if_fail(alloc != NULL);

  widget->allocation = *alloc;
  oscilliscope = GTK_OSCILLISCOPE(widget);

  if (GTK_WIDGET_REALIZED(widget)) {
    gdk_window_move_resize (widget->window,
                            alloc->x, alloc->y,
                            alloc->width, alloc->height);
  }

  oscilliscope->numItemsOffScreen = 0;
  
  g_free(oscilliscope->offScreenDataArray);
  g_free(oscilliscope->onScreenDataArray);
 
  oscilliscope->offScreenDataArray = g_malloc(sizeof(gfloat) * alloc->width);
  oscilliscope->onScreenDataArray = g_malloc(sizeof(gfloat) * alloc->width);
 
  oscilliscope->dataArraySize = alloc->width;

  for (i = 0; i < oscilliscope->dataArraySize; i++) {
    oscilliscope->onScreenDataArray[i] = 0.0;
    oscilliscope->offScreenDataArray[i] = 0.0;
  }
}

void gscope_set_limits(GtkOscilliscope* oscilliscope, gfloat min,
                       gfloat max)
{
  oscilliscope->minValue = min;
  oscilliscope->maxValue = max;
}

void gscope_set_update_policy(GtkOscilliscope* oscilliscope,
                              GtkUpdateType policy)
{
  g_return_if_fail(oscilliscope != NULL);
  g_return_if_fail(GTK_IS_OSCILLISCOPE(oscilliscope));

  oscilliscope->policy = policy;
}

GtkWidget* gscope_new(void)
{
  GtkOscilliscope* oscilliscope;

  oscilliscope = gtk_type_new(gscope_get_type());

  return GTK_WIDGET(oscilliscope);
}

/*
static void gscope_update_trigger(GtkOscilliscope* oscilliscope, gfloat newVal)
{
  if (!oscilliscope->triggerReady) {
    oscilliscope->trigger = newVal;
  }
  oscilliscope->triggerReady = TRUE;
}
*/

gint gscope_add_float(GtkOscilliscope* oscilliscope, gfloat newVal)
{
  g_return_val_if_fail(oscilliscope != NULL, FALSE);

  /*
  gscope_update_trigger(oscilliscope, newVal);

  if (oscilliscope->numFailures < 50) {
    if (oscilliscope->numItemsOffScreen == 0) {
      if (fabs(newVal - oscilliscope->trigger) > 0.2) {
	      oscilliscope->numFailures++;
        return FALSE;
      }
    }
  } else {
    oscilliscope->triggerReady = FALSE;
    gscope_update_trigger(oscilliscope, newVal);
  }

  oscilliscope->numFailures = 0;
*/

  oscilliscope->offScreenDataArray[oscilliscope->numItemsOffScreen++] = newVal;

  if (oscilliscope->numItemsOffScreen == oscilliscope->dataArraySize) {
    guint i;
    gfloat* temp = oscilliscope->onScreenDataArray;
    oscilliscope->onScreenDataArray = oscilliscope->offScreenDataArray;
    oscilliscope->offScreenDataArray = temp;

    gtk_widget_draw(GTK_WIDGET(oscilliscope), NULL);

    memset(oscilliscope->offScreenDataArray, 0, oscilliscope->dataArraySize
	   * sizeof(oscilliscope->offScreenDataArray[i]));
	   
    oscilliscope->numItemsOffScreen = 0;
  }
  
  return TRUE;
}

/*
 * FIXME: Optimize this, sheesh
 */
gint gscope_add_floats(GtkOscilliscope* oscilliscope,
                       gfloat values[],
                       gint n)
{
  gint i;

  g_return_val_if_fail(oscilliscope != NULL, FALSE);

  for (i = 0; i < n; i++) {
    gscope_add_float(oscilliscope, values[i]);
    if (gtk_events_pending()) {
      gtk_main_iteration();
    }
  }

  return TRUE;
}

void gscope_set_maxnumitems(GtkOscilliscope* oscilliscope, guint maxNumItems)
{
  guint i;

  oscilliscope->numItemsOffScreen = 0;
  
  g_free(oscilliscope->offScreenDataArray);
  g_free(oscilliscope->onScreenDataArray);
 
  oscilliscope->offScreenDataArray = g_malloc(sizeof(gfloat) * maxNumItems);
  oscilliscope->onScreenDataArray = g_malloc(sizeof(gfloat) * maxNumItems);
  oscilliscope->dataArraySize = maxNumItems;

  for (i = 0; i < oscilliscope->dataArraySize; i++) {
    oscilliscope->onScreenDataArray[i] = 0.0;
    oscilliscope->offScreenDataArray[i] = 0.0;
  }  
}

guint gscope_get_type(void)
{
  static guint oscilliscope_type = 0;

  if (!oscilliscope_type) {
    GtkTypeInfo oscilliscope_info = {
      "GtkOscilliscope",
      sizeof (GtkOscilliscope),
      sizeof (GtkOscilliscopeClass),
      (GtkClassInitFunc)  gscope_class_init,
      (GtkObjectInitFunc) gscope_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };

    oscilliscope_type = gtk_type_unique(gtk_widget_get_type(),
                                        &oscilliscope_info);
  }

  return oscilliscope_type;
}

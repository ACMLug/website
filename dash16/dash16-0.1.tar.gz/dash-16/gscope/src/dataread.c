#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gtk/gtk.h>

int main(void)
{
  FILE* fp;
  float tmp;
  int   num_items;
  int i;
    
  fp = fopen("data", "r");
  fseek(fp, 0L, SEEK_END);
  num_items = ftell(fp) / sizeof(gfloat);
  rewind(fp);

  printf("num_items: %i\n", num_items);
    
  for (i = 0; i < num_items; i++) {
    fread(&tmp, sizeof(gfloat), 1, fp);
    printf("%f\n", tmp);
  }
    
  fclose(fp);
    
  return 0;
}

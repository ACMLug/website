#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>
#include <sys/stat.h>
#include <gtk/gtk.h>
#include <pthread.h>
#include <sys/ioctl.h>

#include "main.h"
#include "menufactory.h"
#include "filemenu.h"
#include "gtkoscilliscope.h"
#include "fileio.h"
#include "dash16.h"

extern int fd;

void gscope_channel_select(GtkWidget* widget, gpointer data)
{
  struct dash16_channel_range channels = {(int)data, (int)data};

  ioctl(fd, DASH16_CHANNELS_SELECT, &channels);
}

void gscope_toggle_labels(GtkWidget* widget, gpointer data)
{
  GtkOscilliscope* scope = GTK_OSCILLISCOPE(data);

  g_return_if_fail(scope != NULL);

  scope->visibleLabels = GTK_TOGGLE_BUTTON(widget)->active;
  gtk_widget_draw(GTK_WIDGET(scope), NULL);
}

void gscope_toggle_gridlines(GtkWidget* widget, gpointer data)
{
  GtkOscilliscope* scope = GTK_OSCILLISCOPE(data);

  g_return_if_fail(scope != NULL);

  scope->visibleGridlines = GTK_TOGGLE_BUTTON(widget)->active;
  gtk_widget_draw(GTK_WIDGET(scope), NULL);
}

void gscope_toggle_zeroline(GtkWidget* widget, gpointer data)
{
  GtkOscilliscope* scope = GTK_OSCILLISCOPE(data);

  g_return_if_fail(scope != NULL);

  scope->visibleZeroLine = GTK_TOGGLE_BUTTON(widget)->active;
  gtk_widget_draw(GTK_WIDGET(scope), NULL);
}

void gscope_hzoom_change(GtkAdjustment* adj, gpointer data)
{
  gscope_set_maxnumitems(GTK_OSCILLISCOPE(data), adj->value);
  gtk_widget_draw(GTK_WIDGET(data), NULL);
}

void gscope_vzoom_change(GtkAdjustment* adj, gpointer data)
{
  gscope_set_limits(GTK_OSCILLISCOPE(data), -(adj->value), adj->value);
  gtk_widget_draw(GTK_WIDGET(data), NULL);
}

int main(int argc, char *argv[])
{
  pthread_t read_thread;
  GtkWidget*  window;
  GtkWidget*  mainVbox;
  GtkWidget*  menubar;
  GtkWidget*  menubar_handlebox;
  GtkWidget*  hbox;
  GtkWidget*  table;
  GtkWidget*  oscilliscope;
  GtkWidget*  hzoom;
  GtkWidget*  vzoom;
  GtkWidget*  labelsToggle;
  GtkWidget*  zeroLineToggle;
  GtkWidget*  gridToggle;
  GtkWidget*  channel[3];
  GtkWidget*  frame;
  GtkWidget*  frame2;
  GtkWidget*  vbox2;
  GtkWidget*  vbox3;
  GtkWidget*  vbox4;
  GtkObject*  hzoomadj;
  GtkObject*  vzoomadj;
  GSList*     group;
  struct stat statbuf;
  gchar       rcname[RC_BUF_SIZE];

  gtk_init(&argc, &argv);

  g_snprintf(rcname, RC_BUF_SIZE, "%s", "gscoperc");
  if (stat(rcname, &statbuf) == 0) {
    gtk_rc_parse(rcname);
  }

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  mainVbox = gtk_vbox_new(FALSE, 0);
  menubar_handlebox = gtk_handle_box_new();
  hbox = gtk_hbox_new(FALSE, 0);
  vbox3 = gtk_vbox_new(FALSE, 0);
  frame = gtk_frame_new("Options");
  frame2 = gtk_frame_new("Source");
  vbox2 = gtk_vbox_new(FALSE, 0);
  vbox4 = gtk_vbox_new(FALSE, 0);

  labelsToggle = gtk_check_button_new_with_label("Labels");
  zeroLineToggle = gtk_check_button_new_with_label("Zero Line");
  gridToggle = gtk_check_button_new_with_label("Gridlines");
  channel[0] = gtk_radio_button_new_with_label(NULL, "Pure Tone");

  group = gtk_radio_button_group(GTK_RADIO_BUTTON(channel[0]));
  channel[1] = gtk_radio_button_new_with_label(group, "Square Wave");
  group = gtk_radio_button_group(GTK_RADIO_BUTTON(channel[1]));
  channel[2] = gtk_radio_button_new_with_label(group, "Full Range Audio");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(channel[2]), TRUE);
  
  table = gtk_table_new(2, 2, FALSE);
  vzoomadj = gtk_adjustment_new(1.5, 0.1, 8.0, 0.25, 0.25, 0.25);
  oscilliscope = gscope_new();
  vzoom = gtk_vscale_new(GTK_ADJUSTMENT(vzoomadj));
  hzoomadj = gtk_adjustment_new(640.0, 32.0, 4096.0, 32.0, 32.0, 32.0);
  hzoom = gtk_hscale_new(GTK_ADJUSTMENT(hzoomadj));

  gtk_signal_connect(GTK_OBJECT(window), "destroy",
                     GTK_SIGNAL_FUNC(gscope_menu_file_exit), "WM destroy");
  gtk_window_set_title(GTK_WINDOW(window), "GScope");
  gtk_widget_set_usize(GTK_WIDGET(window), 750, 550); 
  GTK_WINDOW(window)->allow_shrink = TRUE;

  gtk_container_border_width(GTK_CONTAINER(mainVbox), 0);
  gtk_container_add(GTK_CONTAINER(window), mainVbox);

  gtk_box_pack_start(GTK_BOX(mainVbox), menubar_handlebox, FALSE, FALSE, 0);
  
  gscope_get_main_menu(window, &menubar);

  gtk_container_add(GTK_CONTAINER(menubar_handlebox), menubar);
  gtk_box_pack_start(GTK_BOX(mainVbox), hbox, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), vbox3, FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox3), frame2, TRUE, FALSE, 2);
  gtk_box_pack_start(GTK_BOX(vbox3), frame, TRUE, FALSE, 2);
  gtk_container_add(GTK_CONTAINER(frame), vbox2);
  gtk_container_add(GTK_CONTAINER(frame2), vbox4);
  
  gtk_signal_connect(GTK_OBJECT(channel[0]), "clicked",
                     GTK_SIGNAL_FUNC(gscope_channel_select),
                     0);
  gtk_box_pack_start(GTK_BOX(vbox4), channel[0], FALSE, FALSE, 0);

  gtk_signal_connect(GTK_OBJECT(channel[1]), "clicked",
                     GTK_SIGNAL_FUNC(gscope_channel_select),
                     1);
  gtk_box_pack_start(GTK_BOX(vbox4), channel[1], FALSE, FALSE, 0);

  gtk_signal_connect(GTK_OBJECT(channel[2]), "clicked",
                     GTK_SIGNAL_FUNC(gscope_channel_select),
                     2);
  gtk_box_pack_start(GTK_BOX(vbox4), channel[2], FALSE, FALSE, 0);

  gtk_signal_connect(GTK_OBJECT(labelsToggle), "clicked",
                     GTK_SIGNAL_FUNC(gscope_toggle_labels),
                     oscilliscope);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(labelsToggle), TRUE);
  gtk_box_pack_start(GTK_BOX(vbox2), labelsToggle, FALSE, FALSE, 0);

  gtk_signal_connect(GTK_OBJECT(zeroLineToggle), "clicked",
                     GTK_SIGNAL_FUNC(gscope_toggle_zeroline),
                     oscilliscope);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(zeroLineToggle), TRUE);
  gtk_box_pack_start(GTK_BOX(vbox2), zeroLineToggle, FALSE, FALSE, 0);


  gtk_signal_connect(GTK_OBJECT(gridToggle), "clicked",
                     GTK_SIGNAL_FUNC(gscope_toggle_gridlines),
                     oscilliscope);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(gridToggle), TRUE);
  gtk_box_pack_start(GTK_BOX(vbox2), gridToggle, FALSE, FALSE, 0);


  gtk_box_pack_start(GTK_BOX(hbox), table, TRUE, TRUE, 0);


  gtk_table_attach(GTK_TABLE(table), oscilliscope, 1, 2, 0, 1,
                   GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND, 1, 1);


  gtk_signal_connect(GTK_OBJECT(vzoomadj), "value_changed",
                     GTK_SIGNAL_FUNC(gscope_vzoom_change), oscilliscope);

  gtk_scale_set_draw_value(GTK_SCALE(vzoom), FALSE);
  gtk_table_attach(GTK_TABLE(table), vzoom, 0, 1, 0, 1,
                   GTK_FILL, GTK_FILL, 1, 1);

  gtk_signal_connect(GTK_OBJECT(hzoomadj), "value_changed",
                     GTK_SIGNAL_FUNC(gscope_hzoom_change), oscilliscope);
  gtk_scale_set_draw_value(GTK_SCALE(hzoom), FALSE);
  gtk_table_attach(GTK_TABLE(table), hzoom, 1, 2, 1, 2,
                   GTK_FILL, GTK_FILL, 1, 1);

  gtk_widget_show_all(window);

  gscope_add_items(oscilliscope);

  gtk_main();
    
  return 0;
}

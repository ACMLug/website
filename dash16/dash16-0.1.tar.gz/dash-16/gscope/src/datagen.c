#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gtk/gtk.h>

#define SIZE 128
#define NUM_WAVES 64

int main(void)
{
  gfloat i;
  guint  j = 0;
  FILE* fp;
  gfloat sinTable[SIZE];
  gfloat tempTable[SIZE];

  fp = fopen("data", "w");
    
  for (i = 0; i < 2 * M_PI; i += 2 * M_PI / (float) SIZE) {
    sinTable[j++] = sin(i);
  }

  for (i = 0; i < NUM_WAVES; i++) {
    for (j = 0; j < SIZE; j++) {
      tempTable[j] = sinTable[j] * (i / 20.0);
    }
    fwrite(tempTable, sizeof(gfloat), SIZE, fp);
  }
  
  fclose(fp);
    
  return 0;
}

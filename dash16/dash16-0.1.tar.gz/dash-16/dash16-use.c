/* This is used if something broke and the module is still reporting
   that something is using it and you KNOW nothing is. Do NOT use this
   otherwise (Again, I am not to be held responsible for the sizzling pile
   of molten metal that used to be your computer :)
     -- Mike Perry
 */
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>                                                      
#include <errno.h>
#include <ctype.h>

#define DEBUG
#include "dash16.h"

#define DEVNAME "dash16"


void main(int argc, char **argv)
{
  int i = 0;
  int fd;
  int num = 1;
  int ioctln = DASH16_MOD_DEC_USE;

  if(argc < 2)
  {
    printf("%s: <increase/decrease> [<howmany>]\n", argv[0]);
    exit(1);
  }


  if((fd = open(DEVNAME, O_RDONLY)) == -1)
  {
    perror("Error opening device");
    exit(errno);
  }

  if(isdigit(argv[1][0]))
    num = atoi(argv[1]);
  else if(strcmp(argv[1], "increase") == 0)
    ioctln = DASH16_MOD_INC_USE;
  else if(strcmp(argv[1], "decrease") == 0)
    ioctln = DASH16_MOD_DEC_USE;

  if(argc == 3 && isdigit(argv[2][0]))
    num = atoi(argv[2]);

  for(i = 0; i < num; i++)
    ioctl(fd, ioctln);

  close(fd);
}

/* This is just a stub module to reset the dash16 in case of emergancy.
 *
 * Simply "insmod dash16-reset.o io=0xAddr; rmmod dash16-reset"
 * and the dash16 will be reset, allowing for proper probing and
 * autodetection after an (unseen) fatal error without reboot.
 *
 * NOTE: Don't use this unless you KNOW the dash16 is at io address
 *	 0xAddr, and there was an error in the driver that caused it to
 *	 exit without resetting the card Otherwise, I am not responsible
 *	 for hunk of sizzling metal that used to be your machine :)
 * 
 *  -- Mike Perry
 */

#include <asm/io.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/errno.h>
#include "dash16.h"

#ifdef MODULE
int	init_module(void);
void    cleanup_module(void);

static void dash16_restore_power_on(int);

int io = -1;
int err = 0;
#define MODULE_NAME "dash16_reset"

MODULE_PARM(io, "i");
EXPORT_NO_SYMBOLS;

/* retore the dash16 power on defaults */
static void dash16_restore_power_on(int io)
{
  outb(PWRON_MUXCTL, io + DASH16_MUXCTL);
  outb(PWRON_CONTROL, io + DASH16_CONTROL);

  outb(DASH16_TIMER_TRIG_CONTROL, io+DASH16_CTR_ENABLE);      

  outb(DASH16_TCTL_SELECT(0) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB) 
       | DASH16_TCTL_MODE(DASH16_HARD_STRB), io+DASH16_CTR_CONTROL);
  outb(0xff, io+DASH16_CTR0);
  outb(0xff, io+DASH16_CTR0);
  PRINTK("%d\n", inb(io+DASH16_CTR0));
  outb(DASH16_TCTL_SELECT(1) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB)
       | DASH16_TCTL_MODE(DASH16_HARD_STRB),
       io+DASH16_CTR_CONTROL);
  outb(0xff, io+DASH16_CTR1);
  outb(0xff, io+DASH16_CTR1);
  PRINTK("%d\n", inb(io+DASH16_CTR1));
  outb(DASH16_TCTL_SELECT(2) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB)
       | DASH16_TCTL_MODE(DASH16_HARD_STRB),
       io+DASH16_CTR_CONTROL);
  outb(0xff, io+DASH16_CTR2);
  outb(0xff, io+DASH16_CTR2);
  PRINTK("%d\n", inb(io+DASH16_CTR2));

}
#ifdef DEBUG
struct dash16_timer_regs timer;
#endif 
int init_module(void)
{


  if(io == -1)
  {
    printk(MODULE_NAME": Must specify the io region of the dash16 to restore "
	   "to power on defaults\n");
    return -EINVAL;
  }
  dash16_restore_power_on(io);

#ifdef DEBUG
  /* Latch then read CTR0 */
  outb(DASH16_TCTL_SELECT(0), io+DASH16_CTR_CONTROL); 
  timer.ctr[0] = inb(io+DASH16_CTR0) | (inb(io+DASH16_CTR0) << 8);
  
  /* Latch then read CTR1 */
  outb(DASH16_TCTL_SELECT(1), io+DASH16_CTR_CONTROL); 
  timer.ctr[1] = inb(io+DASH16_CTR1) | (inb(io+DASH16_CTR1) << 8);
  
  /* Latch then read CTR2 */
  outb(DASH16_TCTL_SELECT(2), io+DASH16_CTR_CONTROL); 
  timer.ctr[2] = inb(io+DASH16_CTR2) | (inb(io+DASH16_CTR2) << 8);
  
  printk(MODULE_NAME": ctr0 0x%x ctr1 0x%x ctr2 0x%x\n", 
	 timer.ctr[0], timer.ctr[1], timer.ctr[2]);
#endif
  printk(MODULE_NAME": IO addr 0x%x restored to dash16 power on defaults. "
	 "Please remove me.\n", io);

  /* There appears to be no way to remove your own module :)
  mod = find_module(MODULE_NAME);

  free_module(mod, 0);
  */

  return 0;
}

void cleanup_module(void)
{
#ifdef DEBUG
  outb(DASH16_TCTL_SELECT(0), io+DASH16_CTR_CONTROL); 
  timer.ctr[0] = inb(io+DASH16_CTR0) | (inb(io+DASH16_CTR0) << 8);
  
  /* Latch then read CTR1 */
  outb(DASH16_TCTL_SELECT(1), io+DASH16_CTR_CONTROL); 
  timer.ctr[1] = inb(io+DASH16_CTR1) | (inb(io+DASH16_CTR1) << 8);
  
  /* Latch then read CTR2 */
  outb(DASH16_TCTL_SELECT(2), io+DASH16_CTR_CONTROL); 
  timer.ctr[2] = inb(io+DASH16_CTR2) | (inb(io+DASH16_CTR2) << 8);

  /* No cleanups to be done! */
  PRINTK(MODULE_NAME": ctr0 0x%x ctr1 0x%x ctr2 0x%x\n", 
	 timer.ctr[0], timer.ctr[1], timer.ctr[2]);
  PRINTK(MODULE_NAME":Status %d\n", inb(io + DASH16_STATUS));
#endif


}

#else
#error This is a reset module to restore the dash16. It should never be in kernel proper.
#endif /* MODULE */

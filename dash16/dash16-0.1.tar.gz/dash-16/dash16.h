/* 
 * Dash16.h header file for use with the dash16 driver by Steve Engelhart,
 * Mike Perry, and Sean O'Connor.
 *
 * This file also falls under the GPL (See COPYING)
 */

#ifdef __KERNEL__
# include <linux/types.h>
#else 
# include <sys/types.h>
  typedef u_int8_t u8;
  typedef u_int16_t u16;
#endif

#ifndef SUCCESS
#define SUCCESS 0 
#endif

#ifndef FAILURE
#define FAILURE 1
#endif


#ifdef __KERNEL__

#define DASH16_MAJOR_NUMBER 240

#define DASH16_DMABUF_SIZE  (PAGE_SIZE*DASH16_DMA_PAGES)

# if (DASH16_DMABUF_SIZE > 0xffff)
#  error DMA buffer cant be grater than 16 pages!
# endif /* BUFFER CHECK */

#define DEVICE_NAME "dash16"

struct dash16_dmabuffer
{
  int half; /* The half of the double buffer we are on */
  char mode; /* The type of buffer this is (DMA_MODE_READ or DMA_MODE_WRITE) */
  char *buf[2]; /* double buffer itself */
};

struct dash16_device {
  int  io_base;
  int  irq;
  int  dma;
  int  w_busy;		/* Busy writing */
  int  r_busy;		/* Busy reading */
  int  open;               /* Is the device open */
  int  chrdev_registered;  /* Has the character device been registered yet? */
  struct wait_queue *waitq;
  int freq;		/* Frequency to sample at or 0 for manual operations */
  int control;	/* Our copy of the current control register */
};

#ifdef DEBUG
# define PRINTK(a...)  printk(DEVICE_NAME " " __FUNCTION__": "##a)
#else
# define PRINTK(x...)
#endif

#define REG(x)             (dash16.io_base + (x))

#define DASH16_LB          0
#define DASH16_HB          1
#define DASH16_MUXCTL      2
#define DASH16_DIGIO       3
#define DASH16_DA0_LB      4
#define DASH16_DA0_HB      5
#define DASH16_DA1_LB      6
#define DASH16_DA1_HB      7
#define DASH16_STATUS      8
#define DASH16_CONTROL     9
#define DASH16_CTR_ENABLE  10
/* 11 is unused */
#define DASH16_CTR_BASE	   12
#define DASH16_CTR0        12
#define DASH16_CTR1        13
#define DASH16_CTR2        14
#define DASH16_CTR_CONTROL 15


#define DASH16_IO_EXTENT           16
#define DASH16_IO_MAX              0x400 /* Max port address  */

/* The following are power on defaults (bytes) of read/write registers 2, 9,
 * 12-14 for probing
 */
#define PWRON_MUXCTL    0x80
#define PWRON_CONTROL   0x00
#define PWRON_CTR0      0xff
#define PWRON_CTR1      0xff
#define PWRON_CTR2      0xff

/* Operations for the control register. Logical OR these. */
#define DASH16_ENABLE_IRQ       (1<<7)
#define DASH16_IRQ(x)           ((x)<<4)
#define DASH16_ENABLE_DMA       (1<<2) /* Must set up kernel dma first */
#define DASH16_ENABLE_TRIGGER   (1<<1) /* Allow trigger pin to start A/D */
#define DASH16_ENABLE_TIMER     (1<<1 | 1) /* Allow timer to start A/D */
#endif /* __KERNEL__ */

/* IOCTL's
   FIXME: 'D' is an available ioctl number (See Documentation/ioctl-number.txt)
 */

#define DASH16_IOC_NUM          'D'


/*  Used with ioctl calls -- we'll pass this to the functions that scan
   the channels */

struct dash16_channel_range {
  u8 start;   /* Start channel for conversion */
  u8 end;   /* End channel for conversion */
};


/* Defines for the control register of the interval timer. All of these macros
   must be ored together to build info to send to the timer control register.
   This is basically for refrence. If you are cool enough to have memorized
   the exact hex values that do various timer ops, then go ahead and use them.
 */
#define DASH16_TCTL_SELECT(x)	(((x) & 3) << 6) /* Select a counter clock */

/* These two say which bit you want to Read/Load (can be ored together to get
   LSB and MSB). For use with the TCTL_RL macro. */
#define DASH16_RL_MSB		(1) 
#define DASH16_RL_LSB		(1<<1)
#define DASH16_TCTL_RL(x)	(((x) & 3) << 4) /* Read/Load op select */

/* Pick ONE of these for use in the TCL_MODE macro. Do NOT try to OR them */
#define DASH16_PTERM		0 /* Pulse on terminal count */		
#define DASH16_PROG_SHOT	1 /* Programmable one shot */
#define DASH16_RATE_GEN		2 /* Rate Generator */
#define DASH16_SQ_WAVE		3 /* Square wave generator */
#define DASH16_SOFT_STRB	4 /* Software tiggered strobe */
#define DASH16_HARD_STRB	5 /* Hardware triggered strobe */
#define DASH16_TCTL_MODE(x)	(((x) & 7) << 1) /* Select configuration */

/* Use... ugh.. *PUKE* owwww... Binary *wretch* Coded *heave* Decimal *ugh* 
   for the format for the timer counter inputs */
#define DASH16_USE_BCD		1
#define DASH16_USE_BIN		0 /* Be like every other human being */
#define DASH16_TCTL_BCD_MODE(x)	((x) & 3)

/* 
   These are our IOCTLS. Note, they all take pointers (even the read-only ones)
   This is for consistancy, not much else. If anyone disagrees, we can change
   that.
   -- Mike Perry

*/


/* Passed to the ioctl calls for controlling the 8253 timer */

  /* NOTE TO PROGRAMMER!!! VERY IMPORTANT if you want RAW MODE to WORK!
   *
   * When you request a read, all three of these registers will be latched 
   * and read into the array, regardless of which you select via the
   * timer_ctl (timer_ctl is ignored entirely and not written to the card)
   * 
   * When in write mode, however, only the register you select via the
   * timer_ctl variable will be written, and the value MUST be properly 
   * aligned.The TOP 8 bytes will only by written when you request write 
   * high byte via the timer control.
   *
   * Defines for setting timer_ctl are above
   *
   * -- Mike Perry
   */
struct dash16_timer_regs {
  u16 ctr[3];
  u8 timer_ctl;
};

/* Start A/D  Note this is probably not advisable, as data will probably be 
   dropped between the ioctl and the read */
#define DASH16_AD_TRIGGER	_IO(DASH16_IOC_NUM, 0)

/* Set channel start/end */
#define DASH16_CHANNELS_SELECT	_IOR(DASH16_IOC_NUM, 1, \
				     struct dash16_channel_range *)

/* Get channel start/end */
#define DASH16_CHANNELS_READ	_IOW(DASH16_IOC_NUM, 2, \
				     struct dash16_channel_range *)

/* Read STATUS register */
#define DASH16_READ_STATUS	_IOW(DASH16_IOC_NUM, 3, u8 *)

/* Read CONTROL register */
#define DASH16_READ_CONTROL	_IOW(DASH16_IOC_NUM, 4, u8 *)


/* Controls the timer control register. Only the low 2 bits are used */
#define DASH16_TIMER_ENABLE	_IOR(DASH16_IOC_NUM, 5, u8 *)

/* The following defines are provided for use with the above ioctl: */

/* Wait for TRIG0 on the card's data port to be high before starting the 
   clocks. This is the default for the card (a carry-over from the 20Khz
    base sample frequency) */
#define DASH16_TIMER_TRIG_CONTROL	1

/* Use internal stable 100Mhz xtal clock instead of the external COUNTER 0 */ 
#define DASH16_TIMER_USE_XTAL_CLK	(1<<1)

/* Timer control Write (raw access to registers) */
#define DASH16_TIMER_CTLW_RAW	_IOR(DASH16_IOC_NUM, 6, \
				     struct dash16_timer_regs *)

/* Timer control Read (raw access to registers) */
#define DASH16_TIMER_CTLR_RAW	_IOWR(DASH16_IOC_NUM, 7, \
				     struct dash16_timer_regs *)

/* Set the freq on the clock (in hertz) */
#define DASH16_SET_FREQ		_IOR(DASH16_IOC_NUM, 8, int *)


/* Restore default settings (sampling on channel 0 at 20Khz) */
#define DASH16_RESTORE_DFL	_IO(DASH16_IOC_NUM, 9)

/* Start conditions for A/D */
#define DASH16_AD_START_CTL  _IOR(DASH16_IOC_NUM, 10, int *)

/*
 * These are for the DASH16_AD_START_CTL. Obviously it's pretty much one or
 * the other. Pass them as an agument to your DASH16_AD_TRIG0_CTL
 */

#ifndef __KERNEL__
# define DASH16_ENABLE_SOFTWARE   (1) /* Allow software only to start A/D */
# define DASH16_ENABLE_TRIGGER    (1<<1) /* Allow trigger pin to start A/D */
# define DASH16_ENABLE_TIMER     (1<<1 | 1) /* Allow timer to start A/D */
#endif /* __KERNEL__ */


#ifdef DEBUG

/* This is used if something broke and the module is still reporting
   that something is using it and you KNOW nothing is. Do NOT use this
   otherwise (Again, I am not to be held responsible for the sizzling pile
   of molten metal that used to be your computer :)
     -- Mike Perry
 */
# define DASH16_MOD_DEC_USE	_IO(DASH16_IOC_NUM, 11)
# define DASH16_MOD_INC_USE	_IO(DASH16_IOC_NUM, 12)

#endif /* DEBUG */

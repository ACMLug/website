/*
    dash16.c -- Kernel 2.2.x driver for the DASH16 ADC/DAC card

                              Copyright (C) 1998     
		  Steve Engelhardt, Mike Perry,  Sean O'Connor
		   University of Illinois at Urbana Champaign

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   dash16.c - v0.1

   This is the fantabulicious driver for the dash16 A/D D/A card. Currently,
   any operations involving the timer (EXCEPT sampling frequency from 0 to 
   500Khz) must be implemented in user space, although a straightforward front
   end to the counter registers does exist.

   This driver is known to work only with MetraByte's Dash-16 card from
   1984. It is rumored to register compatible from a modern card by a
   company that recently bought Metrabyte (see www.metrabyte.com). The
   modern card supports more D/A outs, but of course, these are not
   implemented in this version of the driver. 

   This driver is pretty straightforward. Basically, a direct read on the
   device will produce samples at 20Khz off of channel 0 only. For more
   powerful applications, see the programmer's documentation (and/or the 
   dash16.h file).

   NOTE: This driver uses a revolutionary new proccess in development. It's
   called COMMENTING. If only other Linux kernel developers were aware of
   this powerful new feature of the C language....
   -- Mike Perry

   See fixme notice on dash16_write() before using writes with this card.

*/


#include <asm/dma.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/bitops.h>
#include <asm/errno.h>
#include <linux/types.h>
#include <asm/uaccess.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/ioport.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/wait.h>

#include "dash16.h"

#ifdef MODULE
int            init_module	 (void);
void           cleanup_module	 (void);
#endif /* MODULE */

static int	dash16_probe	 (int io_base);
static int	dash16_initialize(void);
static void	dash16_cleanup	 (void);
static int	dash16_open	 (struct inode*, struct file*);
static int	dash16_release	 (struct inode*, struct file*);
static ssize_t	dash16_read	 (struct file*, char*, size_t, loff_t*);
static ssize_t	dash16_write	 (struct file*, const char*, size_t, loff_t*);
static int	dash16_ioctl	 (struct inode*, struct file*, unsigned int,
                                  unsigned long);
static int	dash16_super_probe(void);
static void	dash16_copy_dmabuf(struct dash16_dmabuffer, const char *, int);
static void	dash16_start_dma  (struct dash16_dmabuffer, int);
static void	dash16_interrupt  (int, void*, struct pt_regs*);
static int	dash16_probe_irq  ();
static void	dash16_restore_power_on();
static void	dash16_set_freq(int, int);


/* Need two buffers. For diagnostics we want to loop outputs to inputs! 
   (Plus prevents possible race condition if the user wants to communicate
    with some analog device in a bidirectional manner */
/* Kernel DMA read Double buffer */
static struct dash16_dmabuffer dma_read = {0, 0, {NULL, NULL}}; 
/* Kernel DMA write */
static struct dash16_dmabuffer dma_write = {0, 0, {NULL, NULL}}; 


static struct dash16_device dash16 = {
  -1,
  -1,
  -1,
  0,
  0,
  0,
  0,
  NULL,
  0,
  0
};

struct file_operations dash16_fops = {
  NULL,
  dash16_read,
  dash16_write,
  NULL,
  NULL,
  dash16_ioctl,
  NULL,
  dash16_open,
  NULL,
  dash16_release,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL
};

/* Local error holding variable. */
int err = 0;

/* These can be outside ifdef MODULE... We can use them in the monolithic 
   implementation too */
int io = -1;
int irq = -1;
int dma = -1;

#ifdef MODULE

MODULE_PARM(io, "i");
MODULE_PARM(irq, "i");
MODULE_PARM(dma, "i");
EXPORT_NO_SYMBOLS;

/* FUNCTION: init_module                                                    */
/* SUMMARY:  This function will put sane values in dash16 for use in        */
/*           dash16_initialize.  To determine sane values, it uses          */
/*           dash16_probe.                                                  */
int init_module(void)
{

  if (dma != 1 && dma != 3) 
  {
    printk(KERN_NOTICE DEVICE_NAME ": dma must be 1 or 3. Check the board. "
	   "It's a switch\n");
    return -EINVAL;
  }
  
  if(irq == -1)
  {
    if((dash16.irq = dash16_probe_irq()) < 0)
    {
      printk(KERN_ERR DEVICE_NAME": This is bad. No free IRQ's\n");
      return -EBUSY;
    }
  }
  else
    dash16.irq = irq;

  if (io == -1) 
  {
    io = dash16_super_probe();
    
    if (io == -1) 
    {
      /* Must free irq's assigning in the irq probing function */
      if(irq == -1)
	free_irq(dash16.irq, NULL);
      return -EINVAL;
    }
  } 
  else if ((err = dash16_probe(io)) != SUCCESS) 
  {
    printk(KERN_NOTICE DEVICE_NAME ": probe failed.  Does the card exist at "
	   "0x%x?\n", io);
    /* Must free irq's assigning in the irq probing function */
    if(irq == -1)
      free_irq(dash16.irq, NULL);
    return err;
  }

  request_region(io, DASH16_IO_EXTENT, DEVICE_NAME);
  dash16.io_base = io;
  dash16.dma     = dma;

  printk("Dash16 found at 0x%x, initializing\n", dash16.io_base); 

  return (dash16_initialize()); 
}

/* FUNCTION: cleanup_module                                                 */
/* SUMMARY:  This function is called after the module is unloaded and       */
/*           requests a cleanup.                                            */
void cleanup_module(void)
{
  dash16_cleanup();
}  
#else
#error A non-modular version of the driver has not been implemented yet.
#endif /* MODULE */

static int dash16_probe_irq(void)
{
  int irq;
  /* FIXME: Serial ports are irq's 3 and 4.. Should we just skip those IRQ's
     in case this is loaded first? */
  for(irq = 3; irq < 8; irq++)
  {
    /* Found free irq */
    if (!request_irq(irq, dash16_interrupt, 0, DEVICE_NAME, NULL)) 
    {
      printk(DEVICE_NAME ": Found free irq at %d\n", irq);
      break;
    }
  }
 
  if(irq == 8)
  {
    return -EINVAL;
  }

  return irq;  

}


/* FUNCTION: dash16_super_probe
 * SUMMARY: Scans all of the possible address space for the DASH16
 */
static int dash16_super_probe(void)
{
  int port, n = 0, aport = -1;
  for (port = 0; port < DASH16_IO_MAX; port += DASH16_IO_EXTENT) {
    if (dash16_probe(port) == SUCCESS) {
      if (n == 1)
        printk("Multiple possible dash16's found at 0x%x, ", aport);
      else if (n > 1)
        printk(" 0x%x,", aport);

      n++;
      aport = port;
    }
  }
  
  if (n > 1)
  {
    printk(" and 0x%x\n", aport);
    return -1;
  }
  else if (n == 0)
  {
    printk(KERN_NOTICE "Dash16 not found anywhere in its possible address "
	   "space (0 to 0x%x)\n", DASH16_IO_MAX);
    return -1;
  }

  return aport;
}

/* FUNCTION: dash16_probe                                                   
 * SUMMARY:  This function will "probe" for the existence of the DASH-16 at 
 *           the specified io_base, usually 0x300.  It returns SUCCESS if   
 *           the DASH-16 is found, and FAILURE otherwise.                   
 */
static int dash16_probe(int io_base)
{

  if(check_region(io_base, DASH16_IO_EXTENT)) 
  {
    return -EBUSY;
  }


  if((inb(io_base + DASH16_MUXCTL) == PWRON_MUXCTL) 
     && (inb(io_base + DASH16_CONTROL) == PWRON_CONTROL))

/* BIG FIXME: CHECK AN ALTERNATE CARD!!! THIS SHOULD WORK
   && (inb(io_base + DASH16_CTR0) == PWRON_CTR0) 
   && (inb(io_base + DASH16_CTR1) == PWRON_CTR1) 
   && (inb(io_base + DASH16_CTR2) == PWRON_CTR2)) */
  {
    return SUCCESS;
  }
  else
  {
#ifdef DEBUG
    printk("Card not found at 0x%x\n", io_base);
    printk("Regs:  2: 0x%x, 9: 0x%x, 12: 0x%x, 13: 0x%x, 14 0x%x\n", 
	   inb(io_base + DASH16_MUXCTL), inb(io_base + DASH16_CONTROL),
	   inb(io_base + DASH16_CTR0), inb(io_base + DASH16_CTR1),
	   inb(io_base + DASH16_CTR2));
#endif /* DEBUG */                
    return -ENXIO;
  }

}

/* FUNCTION: dash16_initialize                                              */
/* SUMMARY:  This function requests the appropriate resources from the      */
/*           kernel, initializes the card, and registers the character      */
/*           device.  It requires dash16 to be filled with the            */
/*           appropriate data.                                              */
static int dash16_initialize(void)
{
  /* FIXME: ORDER is Important here! */
  if (dash16.io_base == -1) 
  {
    printk(KERN_ERR DEVICE_NAME ": dash16_initialize was called with io_base "
	   "= -1\n");
    return -EINVAL;
  }

  if ((err = register_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME, &dash16_fops)))
  {
    printk(KERN_ERR DEVICE_NAME ": unable to register character device.\n");
    dash16_restore_power_on();
    return err;
  }

  dash16.chrdev_registered = 1;

  /* This is as the french say, not good.. If we request the same irq twice,
     the request fails, and then we are left with an unfreed irq*/
  if(irq != -1)
  {
    if ((err = request_irq(dash16.irq, dash16_interrupt, 0, DEVICE_NAME, 
			   NULL)))
    {
      printk(KERN_WARNING DEVICE_NAME": Can't allocate IRQ %d\n",  
	     dash16.irq);
      if (dash16.chrdev_registered) 
      {
	if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) 
	{
	  dash16.chrdev_registered = 0;
	  printk(KERN_ERR DEVICE_NAME": error in unregister_chrdev, kernel on "
		 "fire!!\n");
	}
	
	dash16.chrdev_registered = 0;
      }
      dash16_restore_power_on();
      release_region(dash16.io_base, DASH16_IO_EXTENT);

      return err;
    }
  }

  if((dma_read.buf[0] = (char*)kmalloc(DASH16_DMABUF_SIZE, GFP_KERNEL|GFP_DMA))
     == NULL)
  {
    
    printk(KERN_WARNING DEVICE_NAME": Can't allocate memory for DMA\n");
    if (dash16.chrdev_registered) 
    {
      if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) 
      {
	printk(KERN_ERR DEVICE_NAME": Error in unregister_chrdev, kernel on "
	       "fire!!\n");
      }
	
      dash16.chrdev_registered = 0;
    }
    dash16_restore_power_on();
    release_region(dash16.io_base, DASH16_IO_EXTENT);
    free_irq(dash16.irq, NULL);
    return -EIO;

  }
  if((dma_read.buf[1] = (char*)kmalloc(DASH16_DMABUF_SIZE, GFP_KERNEL|GFP_DMA))
     == NULL)
  {
    printk(KERN_WARNING DEVICE_NAME ": Can't allocate memory for DMA\n");
    if (dash16.chrdev_registered) 
    {
      if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) 
      {
	printk(KERN_ERR DEVICE_NAME": Error in unregister_chrdev, kernel on "
	       "fire!!\n");
      }
	
      dash16.chrdev_registered = 0;
    }
    dash16_restore_power_on();
    release_region(dash16.io_base, DASH16_IO_EXTENT);
    free_irq(dash16.irq, NULL);
    kfree(dma_read.buf[0]);
    return -EIO;
  }
  dma_read.mode = DMA_MODE_READ;

  if((dma_write.buf[0]=(char*)kmalloc(DASH16_DMABUF_SIZE, GFP_KERNEL|GFP_DMA))
     == NULL)
  {
    printk(KERN_WARNING DEVICE_NAME ": Can't allocate memory for DMA\n");
    
    if (dash16.chrdev_registered) 
    {
      if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) 
      {
	printk(KERN_ERR DEVICE_NAME": Error in unregister_chrdev, kernel on "
	       "fire!!\n");
      }
	
      dash16.chrdev_registered = 0;
    }
    dash16_restore_power_on();
    release_region(dash16.io_base, DASH16_IO_EXTENT);
    free_irq(dash16.irq, NULL);
    kfree(dma_read.buf[0]);
    kfree(dma_read.buf[1]);
    return -EIO;
  }
  if((dma_write.buf[1]=(char*)kmalloc(DASH16_DMABUF_SIZE, GFP_KERNEL|GFP_DMA))
     == NULL)
  {
    printk(KERN_WARNING DEVICE_NAME ": Can't allocate memory for DMA\n");
    if (dash16.chrdev_registered) 
    {
      if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) 
      {
	printk(KERN_ERR DEVICE_NAME": Error in unregister_chrdev, kernel on "
	       "fire!!\n");
      }
	
      dash16.chrdev_registered = 0;
    }
    dash16_restore_power_on();
    release_region(dash16.io_base, DASH16_IO_EXTENT);
    free_irq(dash16.irq, NULL);
    kfree(dma_read.buf[0]);
    kfree(dma_read.buf[1]);
    kfree(dma_write.buf[0]);
    return -EIO;
  }
  dma_write.mode = DMA_MODE_WRITE;

#ifdef DEBUG
  memset(dma_read.buf[0], 0x66, DASH16_DMABUF_SIZE);
  memset(dma_read.buf[1], 0x66, DASH16_DMABUF_SIZE);
  memset(dma_write.buf[0], 0x66, DASH16_DMABUF_SIZE);
  memset(dma_write.buf[1], 0x66, DASH16_DMABUF_SIZE);
#endif

  /* New kernel programmers beware. This is needed before using a waitqueue */
  init_waitqueue(&(dash16.waitq));

 
  /* This is the power on default anyways.. */
  outb(0, REG(DASH16_CONTROL)); 
  outb(DASH16_ENABLE_TIMER, REG(DASH16_CONTROL)); 

  
  /* Set default state (read channel 0, use timer, frequency of 20Khz */
  dash16.control = DASH16_IRQ(dash16.irq) | DASH16_ENABLE_IRQ | 
    DASH16_ENABLE_TIMER | DASH16_ENABLE_DMA;

  outb(dash16.control, REG(DASH16_CONTROL));

  /* Wait for trig0 to be high before starting the clocks for sampling */
  outb(DASH16_TIMER_TRIG_CONTROL, REG(DASH16_CTR_ENABLE));

  dash16.freq = 20000;

  /* Default is read channel 0 only */
  outb(0, REG(DASH16_MUXCTL)); 
  
  dash16_set_freq(2, (int) (500000 / dash16.freq));

  printk(DEVICE_NAME ": setting interrupt line on card to %d.\n", dash16.irq);
 
  return 0;
}

/*
 * FUNCTION: dash16_restore_power_on
 * SUMMARY: Restore power on defaults of the card to find it in future 
 *          probes.
 */
static void dash16_restore_power_on(void)
{
  outb(PWRON_MUXCTL, REG(DASH16_MUXCTL));
  outb(PWRON_CONTROL, REG(DASH16_CONTROL));
  outb(PWRON_CTR0, REG(DASH16_CTR0));
  outb(PWRON_CTR1, REG(DASH16_CTR1));
  outb(PWRON_CTR2, REG(DASH16_CTR2));
}

/* FUNCTION: dash16_cleanup                                                */
/* SUMMARY:  This function will clean up after the module.                  */
static void dash16_cleanup(void)
{

  /* FIXME: ORDER is Important here! */
  if (MOD_IN_USE) {
    printk(KERN_NOTICE DEVICE_NAME": Device busy, remove delayed.\n");
    return;
  }
  
  free_irq(dash16.irq, NULL);

  if (dash16.chrdev_registered) {
    if (unregister_chrdev(DASH16_MAJOR_NUMBER, DEVICE_NAME) < 0) {
      printk(KERN_ERR DEVICE_NAME": error in unregister_chrdev!\n");
    }

    dash16.chrdev_registered = 0;
  }

  dash16_restore_power_on();

  if(dash16.io_base != -1)
    release_region(dash16.io_base, DASH16_IO_EXTENT);

  kfree(dma_write.buf[0]);
  kfree(dma_write.buf[1]);
  kfree(dma_read.buf[0]);
  kfree(dma_read.buf[1]);

}

static int dash16_open(struct inode* a, struct file* b)
{
  /* Don't allow access if already opened */
  if(b->f_count > 1)
  {
    printk(KERN_WARNING DEVICE_NAME": Error, this device is not reentrant\n");
    return -EBUSY;
  }
  

  if((err = request_dma(dash16.dma, DEVICE_NAME)))
  {
    printk(KERN_WARNING DEVICE_NAME": Can't allocate DMA%d!\n", 
	   dash16.irq);

    return err;
  }

  /* Set default state (read channel 0, use timer, frequency of 20Khz */
  dash16.control = DASH16_IRQ(dash16.irq) | DASH16_ENABLE_IRQ | 
    DASH16_ENABLE_TIMER | DASH16_ENABLE_DMA;

  outb(dash16.control, REG(DASH16_CONTROL));

  /* Wait for trig0 to be high before starting the clocks for sampling */
  outb(DASH16_TIMER_TRIG_CONTROL, REG(DASH16_CTR_ENABLE));

  dash16.freq = 20000;

  /* Default is read channel 0 only */
  outb(0, REG(DASH16_MUXCTL)); 
  
  dash16_set_freq(2, (int) (500000 / dash16.freq));

  /* Tell the card we're ready for an interrupt. */
  outb(0, REG(DASH16_STATUS));

  MOD_INC_USE_COUNT;

  return SUCCESS;
}

static int dash16_release(struct inode* a, struct file* b)
{
  free_dma(dash16.dma);

  /* Tell the card we're ready for an interrupt. */
  outb(0, REG(DASH16_STATUS));

  MOD_DEC_USE_COUNT;

  return SUCCESS;
}

/* FUNCTION: dash16_read 
   PERSON TO BLAME: Mike Perry
   SUMMARY: Reads from DMA using double buffering 
 */
static ssize_t dash16_read(struct file *a, char *buf, size_t c, loff_t *d)
{
  /* Amount copied from kernel dma buffer to user space. */
  int copied_to_buf;
  size_t size = c; // For checking..


  if(dash16.r_busy)
  {
    printk(KERN_WARNING DEVICE_NAME": Already reading via another process. "
	   "We are not reentrant\n");
    return -EBUSY;
  }
  dash16.r_busy=1;

  PRINTK("Status 0x%x 1\n", inb(REG(DASH16_STATUS)));

  /* Get ourselves setup so we can just read in nice blocks */
  copied_to_buf = c % (DASH16_DMABUF_SIZE);

  /* If we are an even anmount, don't read! */
  if(copied_to_buf != 0)
  {
    dash16_start_dma(dma_read, copied_to_buf);
    c -= copied_to_buf;

    PRINTK("Status 0x%x 2\n", inb(REG(DASH16_STATUS)));
    interruptible_sleep_on(&dash16.waitq);
    
    /* IF the interrupt was not caused by us (IE ctrl-c), gracefully stop */
    if(signal_pending(current))
    {
      dash16.r_busy = 0;
      return -ERESTARTSYS;
    }
  }

  if(c > 0)
  {
    dash16_start_dma(dma_read, DASH16_DMABUF_SIZE);

    /* Copy the first read (1st half, buf[0]) into buf */
    /* Already subtracted this chunk from c above */

    /* The last segment will only be in kernel space if above is read! */
    if(copied_to_buf != 0)
      dash16_copy_dmabuf(dma_read, buf, copied_to_buf);

    for(; c > DASH16_DMABUF_SIZE; c -= DASH16_DMABUF_SIZE)
    {

      PRINTK("In for loop c = %d\n", c);
      interruptible_sleep_on(&dash16.waitq);
      /* If the interrupt was not caused by us (IE ctrl-c), gracefully stop */
      if(signal_pending(current))
      {
	dash16.r_busy = 0;
	return -ERESTARTSYS;
      }
      dash16_start_dma(dma_read, DASH16_DMABUF_SIZE);

      /* Copy the previous read (a read on half 1) to buf[copied_to_buf] */
      dash16_copy_dmabuf(dma_read, buf+copied_to_buf, DASH16_DMABUF_SIZE);
      copied_to_buf += DASH16_DMABUF_SIZE;

    }

    /* Since our counter c is based on how much WROTE to userland, we still 
       have one more dma block in kernel space to ship to userland. So:
       Wait for that DMA to finish, then get the last chunk of stuff from the 
       buffer */

    interruptible_sleep_on(&dash16.waitq);
    /* If the interrupt was not caused by us (IE ctrl-c), gracefully stop */
    if(signal_pending(current))
    {
      dash16.r_busy = 0;
      return -ERESTARTSYS;
    }
    c-= DASH16_DMABUF_SIZE;
    PRINTK("In for loop copied_to_buf  = %d\n", copied_to_buf);
    /* copy the last chunk of DMA memory read */
    dash16_copy_dmabuf(dma_read, buf+copied_to_buf, DASH16_DMABUF_SIZE);
    copied_to_buf += DASH16_DMABUF_SIZE;  
  }
  else /* c <= 0 */
  {
    /* Already subtracted this chunk from c above */
    dash16_copy_dmabuf(dma_read, buf, copied_to_buf);
  }

  

  if(c != 0 || size != copied_to_buf)
  {
    if(size > copied_to_buf)
      printk(KERN_WARNING DEVICE_NAME": Underwrote buffer by %d", 
	     (size - copied_to_buf));
    else if(size < copied_to_buf)
      printk(KERN_WARNING DEVICE_NAME": Overwrote userspace buffer by %d! "
	     "We sorry :)\n", (copied_to_buf - size));
    else
      printk(DEVICE_NAME": c != 0 in " __FUNCTION__ "\n");
  }


  dash16.r_busy=0;

  return copied_to_buf;
}

/* FUNCTION: dash16_write 
   PERSON TO BLAME: Mike Perry's evil drunk twin
   SUMMARY: Write to DMA using double buffering
   FIXME: This writes the proper amount of data, and doesn't write 
   uninitialized data (as far as I can tell with -DDEBUG), yet when I hook
   it up to an oscilliscope, it registers nothing...
	  
 */
static ssize_t dash16_write(struct file *a, const char *buf, size_t c, 
			    loff_t *d)
{
  /* Amount wrote to kernel space dma buffer */
  int wrote_to_dmabuf;
  size_t size = c; // For checking..


  if(dash16.w_busy)
  {
    printk(KERN_WARNING DEVICE_NAME": Already writing via another process. "
	   "We are not reentrant\n");
    return -EBUSY;
  }

  dash16.w_busy=1;

  wrote_to_dmabuf = (c % DASH16_DMABUF_SIZE);
  /* Don't do anything if we have an exact multiple of DASH16_DMABUF_SIZE */
  if(wrote_to_dmabuf != 0)
  {
    dash16_copy_dmabuf(dma_write, buf, wrote_to_dmabuf);
  }
  else /* Start a block, so that we're on even keel in both cases */
  {
    wrote_to_dmabuf = DASH16_DMABUF_SIZE;
    dash16_copy_dmabuf(dma_write, buf, wrote_to_dmabuf);
  }
  /* Write the first half block to dma */
  dash16_start_dma(dma_write, wrote_to_dmabuf);
  c -= wrote_to_dmabuf;
  

  if(c > 0)
  {
    /* Copy the second segmant of userspace to the second half of the DMA 
       buffer */
    dash16_copy_dmabuf(dma_write, buf+wrote_to_dmabuf, DASH16_DMABUF_SIZE);
    wrote_to_dmabuf += DASH16_DMABUF_SIZE;
    
    for(; c > DASH16_DMABUF_SIZE; c -= DASH16_DMABUF_SIZE)
    {

      /* Wait for dma to come available to write the second half*/
      interruptible_sleep_on(&dash16.waitq);

      PRINTK("In for loop\n");

      /* Write the second half */
      dash16_start_dma(dma_write, DASH16_DMABUF_SIZE);

      /* Copy more data from userspace (1st half, buf[wrote_to_dmabuf]]) 
	 into DMA Buffer */
      dash16_copy_dmabuf(dma_write, buf+wrote_to_dmabuf, DASH16_DMABUF_SIZE);
      wrote_to_dmabuf += DASH16_DMABUF_SIZE;
    }

    /* Wait for last operation to finish, then write the last chunk to DMA */
    interruptible_sleep_on(&dash16.waitq);

    /* Since the wrote_to_dmabuf counts how much we WROTE to dma, we 
       still have a chunk to write */
    dash16_start_dma(dma_write, DASH16_DMABUF_SIZE);
    c -= DASH16_DMABUF_SIZE;
  }
  interruptible_sleep_on(&dash16.waitq);

  if(c != 0 || size != wrote_to_dmabuf)
  {
    if(size > wrote_to_dmabuf)
      printk(KERN_WARNING DEVICE_NAME": Underwrote kernel DMA buffer by %d", 
	     (size - wrote_to_dmabuf));
    else if(size < wrote_to_dmabuf)
      printk(KERN_EMERG DEVICE_NAME": Overwrote KERNEL buffer by %d!!! "
	     "We sorry :)\n", (wrote_to_dmabuf - size));
    else
      printk(DEVICE_NAME": c != 0 in " __FUNCTION__ "\n");
  }

  dash16.w_busy=0;

  return wrote_to_dmabuf;

}
/* Code heartlessly stolen from Professor Sylvian Ray of UIUC. 
   Adapted for dash16.c by Mike Perry */
static void dash16_set_freq(int clk1cnt, int clk2cnt)
{

  /* Set ctr0 to default */
  outb(DASH16_TCTL_SELECT(0) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB),
       REG(DASH16_CTR_CONTROL));
  /* set clock frequencies to produce sampling frequency(hertz) */

  /* divide clk1 by 2 --> 500KHz */

  /* config clk2 */
  outb(DASH16_TCTL_SELECT(2) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB) |
       DASH16_TCTL_MODE(DASH16_RATE_GEN) | 
       DASH16_TCTL_BCD_MODE(DASH16_USE_BIN), 
       REG(DASH16_CTR_CONTROL));
    
  /* write lo byte clk2 count */
  outb(clk2cnt & 0x00ff, REG(DASH16_CTR2));


  /* write hi byte to clk2*/
  outb((clk2cnt >> 8) & 0x00ff, REG(DASH16_CTR2));  

  /* config clk1 */
  outb(DASH16_TCTL_SELECT(1) | DASH16_TCTL_RL(DASH16_RL_LSB|DASH16_RL_MSB) |
       DASH16_TCTL_MODE(DASH16_RATE_GEN) | 
       DASH16_TCTL_BCD_MODE(DASH16_USE_BIN), 
       REG(DASH16_CTR_CONTROL));

  /* Write low byte of the clock1 counter*/
  outb(clk1cnt & 0x00ff, REG(DASH16_CTR1));

  /* Write high byte */
  outb((clk1cnt >> 8) & 0x00ff, REG(DASH16_CTR1));


}

/* FUNCTION: dash16_ioctl
   PERSON LARGELY TO BLAME: Mike Perry 
   SUMMARY: Handles registers that can't be accessed from userspace 
   	    Gives user almost total control over writing to the registers.
	    Assumes he (mostly) knows what he is doing. Please see
            dash16.h/dash16.txt
*/

static int dash16_ioctl(struct inode *inodeptr, struct file *fileptr,
                        unsigned int iocmd, unsigned long ioarg)
{
  /* the structs we'll need to copy to/from */
  struct dash16_channel_range chans;
  struct dash16_timer_regs timer;
  u8 arg8;
  int arg_int;
  int ctr_reg;
  /* this makes sure the user supplied the correct device file to ioctl() */
  int devicenum = MAJOR(inodeptr->i_rdev);


  if (dash16.w_busy || dash16.r_busy)
  {
    return -EBUSY;
  }

  if (devicenum != DASH16_MAJOR_NUMBER)
  {
    printk(__FUNCTION__ ": ioctl'ed %d, but my major number is %d!\n", 
	   devicenum, DASH16_MAJOR_NUMBER);
    return -ENODEV;
  }


  switch (iocmd) 
  {

  case DASH16_AD_TRIGGER:
    /* Issue a A/D trigger by writing random value to base addr */
    outb(1, REG(DASH16_LB));
    break;

  case DASH16_CHANNELS_SELECT:
    copy_from_user(&chans, (struct dash16_channel_range *)ioarg, 
		   sizeof(struct dash16_channel_range));
    outb(chans.start | (chans.end << 4), REG(DASH16_MUXCTL)); 
    break;

  case DASH16_CHANNELS_READ:
    chans.start = inb(REG(DASH16_MUXCTL)) & 0xf;
    chans.end = (inb(REG(DASH16_MUXCTL)) >> 4) & 0xf;
    copy_to_user((struct dash16_channel_range *)ioarg, &chans, 
		 sizeof(struct dash16_channel_range));
    break;

  case DASH16_READ_STATUS:
    arg8 = inb(REG(DASH16_STATUS));
    put_user(arg8, (u8 *)ioarg);
    break;

  case DASH16_READ_CONTROL:
    arg8 = inb(REG(DASH16_CONTROL));
    put_user(arg8, (u8 *)ioarg);
    break;

  case DASH16_TIMER_ENABLE:
    get_user(arg8, (u8 *)ioarg);
    outb(arg8, REG(DASH16_CTR_ENABLE));
    break;

  case DASH16_TIMER_CTLW_RAW:

    dash16.freq = 0;

    /* Tell control register we want to use the timer to start A/D */
    dash16.control = (dash16.control & 0xfffc) | DASH16_ENABLE_TIMER;

    outb(dash16.control, REG(DASH16_CONTROL));

    copy_from_user(&timer, (struct dash16_timer_regs *)ioarg, 
		   sizeof(struct dash16_timer_regs));
    outb(timer.timer_ctl, REG(DASH16_CTR_CONTROL));

    /* This is our hack to tell that they don't want to write, only select
     * (Which restores default values)
     */
    if(timer.ctr[0] == timer.ctr[1] == timer.ctr[2] == -1)
      break;

    /* Ok, this is kida hokey. We check ourselves to see which ctr register
       he wants to write to (contained at 0011000), and only write to it.
    */
    ctr_reg = (timer.timer_ctl >> 6) & 3;

    if(ctr_reg > 2)
    {
      printk(DEVICE_NAME" ioctl: Illegal counter register 3!\n");
      return -EINVAL;
    }


    /* get the RL0/RL1 bits (00110000) */
    switch((timer.timer_ctl >> 4) & 3)
    {
    case 0: /* Latch */
      printk(DEVICE_NAME" ioctl: Why the hell are you doing a WRITE on the "
	     "counter latch??\n");
      return -EINVAL;

    case 1: /* Write high byte */
      outb( (timer.ctr[ctr_reg] >> 8) & 0x00ff, 
	    REG(DASH16_CTR_BASE + ctr_reg));      
      break;

    case 2: /* Write low byte */
      outb((timer.ctr[ctr_reg] & 0xff), REG(DASH16_CTR_BASE + ctr_reg));
      break;

    case 3: /* Write low byte, then high byte */
      outb((timer.ctr[ctr_reg] & 0xff), REG(DASH16_CTR_BASE + ctr_reg));
      outb((timer.ctr[ctr_reg] >> 8) & 0x00ff, 
	   REG(DASH16_CTR_BASE + ctr_reg));      
      break;

    default:
      printk(DEVICE_NAME" ioctl: Mike Perry can't do binary->hex "
	     "conversions!!\n");
    }

    break;


  case DASH16_TIMER_CTLR_RAW:
    copy_from_user(&timer, (struct dash16_timer_regs *)ioarg, 
		   sizeof(struct dash16_timer_regs));


    /* Latch then read CTR0. Note, the manual is WRONG in this regard
       WRONG WRONG WRONG WRONG!!! WRONG!
       You should NEVER EVER set the RL registers to LSB/MSB on read, even
       when you latch first (as it seems to imply). This comment is mainly
       to vent some of my steam, and to warn future developers of this
       pitfall. See the basic code they give in chapter 5. That's
       what FINALLY clued me (after 2.5 hours of testing!!!!)
       -- Mike Perry!
    */
    outb(DASH16_TCTL_SELECT(0), REG(DASH16_CTR_CONTROL)); 
    timer.ctr[0] = inb(REG(DASH16_CTR0)) | (inb(REG(DASH16_CTR0)) << 8);

    /* Latch then read CTR1 */
    outb(DASH16_TCTL_SELECT(1), REG(DASH16_CTR_CONTROL)); 
    timer.ctr[1] = inb(REG(DASH16_CTR1)) | (inb(REG(DASH16_CTR1)) << 8);

    /* Latch then read CTR2 */
    outb(DASH16_TCTL_SELECT(2), REG(DASH16_CTR_CONTROL)); 
    timer.ctr[2] = inb(REG(DASH16_CTR2)) | (inb(REG(DASH16_CTR2)) << 8);
      

    copy_to_user((struct dash16_timer_regs *)ioarg, &timer, 
		 sizeof(struct dash16_timer_regs));
    break;
    
  case DASH16_SET_FREQ:
    get_user(arg_int, (int *)ioarg);

    /* Tell control register we want to use the timer to start A/D */
    dash16.control = (dash16.control & 0xfffc) | DASH16_ENABLE_TIMER;
    outb(dash16.control, REG(DASH16_CONTROL));

    /* Don't start clocks until trig0 goes high */
    outb(DASH16_TIMER_TRIG_CONTROL, REG(DASH16_CTR_ENABLE));

    dash16.freq = arg_int;

    dash16_set_freq(2, (int) (500000 / arg_int));

    break;

  case DASH16_AD_START_CTL:
    get_user(arg_int, (int *)ioarg);
    
    /* make sure the user doesn't try to screw us :) */
    arg_int &= 3;
    dash16.control = (dash16.control & 0xfffc) | arg_int;
    outb(dash16.control, REG(DASH16_CONTROL));
    break;
    
  case DASH16_RESTORE_DFL:
    /* Set default state (read channel 0, use timer, frequency of 20Khz */
    dash16.control = DASH16_IRQ(dash16.irq) | DASH16_ENABLE_IRQ | 
      DASH16_ENABLE_TIMER | DASH16_ENABLE_DMA;

    outb(dash16.control, REG(DASH16_CONTROL));

    /* Wait for trig0 to be high before starting the clocks for sampling */
    outb(DASH16_TIMER_TRIG_CONTROL, REG(DASH16_CTR_ENABLE));
  
    dash16.freq = 20000;

    /* Default is read channel 0 only */
    outb(0, REG(DASH16_MUXCTL)); 
  
    dash16_set_freq(2, (int) (500000 / dash16.freq));

    break;

    /* For emergency purposes only */ 
#if defined(DEBUG)
  case DASH16_MOD_DEC_USE:
    MOD_DEC_USE_COUNT;
    break;

  case DASH16_MOD_INC_USE:
    MOD_INC_USE_COUNT;
    break;

#endif /* DEBUG */
    
  default:
    printk(DEVICE_NAME": Invalid ioctl %d\n", iocmd);

  }

  return SUCCESS;
}

/* FUNCTION: dash16_copy_dmabuf
   PERSON TO BLAME: Mike Perry
   SUMMARY: Copy dma data to/from userspace.
*/
static void dash16_copy_dmabuf(struct dash16_dmabuffer dma, const char *buf, 
			       int count)
{
  PRINTK("amount to tranfer to/from user space: %d\n",count);
  /* FIXME: Copying the wrong half?? */
  PRINTK("dma half to transfer: %d\n", dma.half);
  if(dma.mode == DMA_MODE_WRITE)
  {
    /* Write the data to the current block of DMA (not !half, because
       we write the DMA buffer, THEN write it to card) */
    copy_from_user(dma.buf[dma.half], buf, count);
#ifdef DEBUG
    PRINTK("clearing (other) half %d of memory (with 0x66)\n", (dma.half+1)%2);
    memset(dma.buf[(dma.half+1)%2], 0x66, DASH16_DMABUF_SIZE);
#endif
  }
  else
  {
    /* We write the DMA data to the kernel buffer, increment half, then ship
       the previous (half, not !half) kernel buffer block to userland */
    copy_to_user((char *)buf, dma.buf[dma.half], count);
    /* clear this half of data */
#ifdef DEBUG
    PRINTK("clearing half %d of memory (with 0x66)\n", dma.half);
    memset(dma.buf[dma.half], 0x66, DASH16_DMABUF_SIZE);
#endif
  }


} 

/* FUNCTION: dash16_copy_dmabuf
   PERSON TO BLAME: Mike Perry
   SUMMARY: Start a dma transfer on the dma double buffer
*/
static void dash16_start_dma(struct dash16_dmabuffer dma, int count)
{
  int flags;

  /* DON'T do a cli/save flags here. If you look up claim_dma_lock, they
     do it, plus they have the advantage of being SMP safe */
  flags = claim_dma_lock();

  disable_dma(dash16.dma);
  clear_dma_ff(dash16.dma);
  set_dma_mode(dash16.dma, dma.mode);

  set_dma_addr(dash16.dma, (int) (dma.buf[dma.half]));

  set_dma_count(dash16.dma, count);
  enable_dma(dash16.dma) ;

  /* Tell the card we got it's interrupt */
  outb(0, REG(DASH16_STATUS));

  release_dma_lock(flags);

  PRINTK("read counter= %d\n", count);
  PRINTK("dma half to transfer: %d\n", dma.half);

#ifdef DEBUG
  {
    int i;
    for(i= 0; i < count; i++)
    {
      if(dma.buf[dma.half][i] == 0x66)
      {
	PRINTK("Uninitialized memory written starting at count %d", i);
	break;
      }
    }
  }
#endif

  dma.half = (dma.half+1)%2;
  PRINTK("next transfer half will be %d\n", dma.half);

  
}

/* FUNCTION: dash16_interrupt
   SUMMARY: This should be all we need, unless we implement a waitq
   	    for read, and one for write. Either way, all that needs
	    to be done here is to wake up the waiting function, and have
	    it continue DMA read/write. (IRQ on dash16 _only_ signals
	    that dma is done)
*/
static void dash16_interrupt(int irq, void* dev, struct pt_regs* regs)
{
  /* FIXME: is it possible to have an interrupt BEFORE we set up a sleep 
     for the waitq? ANd if so, will that be a null pointer derefrence? */
  PRINTK("interrupt called\n");
  wake_up_interruptible(&dash16.waitq);
  PRINTK("Returning from interrupt\n");
}

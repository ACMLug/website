/* code to get username and stuff */
/* lug@uiuc.edu */

/* Written by Chris Stamborski */
/* Edited and debugged by Keith T. Garner */

#include <pwd.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char* whoami() {
  struct passwd *pwd;
  char *username;
  char *temp;
  
  if ((temp = getenv("BCAST_NAME")) != NULL) {
	username = malloc(strlen(temp) + 1);
	strcpy(username, temp);
	return username;
  }

  if ((pwd = getpwuid(getuid())) == NULL) {
    fprintf(stderr, "Who the hell are you?\n");
  }
  
  if ((username = malloc(strlen(pwd->pw_gecos) + 1)) == NULL) {
    fprintf(stderr, "Not enough memory.\n");
  }

  strcpy(username, pwd->pw_gecos);

  return username;
}

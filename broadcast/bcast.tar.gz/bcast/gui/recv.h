int RecvInit(void);
void RecvDeInit(void);
void RecvIO(void);

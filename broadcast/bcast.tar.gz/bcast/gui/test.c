#include "send.h"

void main() {
	send_bcast("UIUC-ACM", "anything", "This is a test of this shit", 9);
}

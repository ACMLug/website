#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>
#include <string.h>
#include <signal.h>
#include "send.h"
#include "icon.h"
#include "getid.h"

#define SEND_LENGTH 388
extern ATP atp;

/* void send(int icon_no, char *obj, char *type, char *zone, char *message) */
void send_bcast(char *zone, char *obj, char *message, int icon_no)
{
	extern int errno;
	ATP latp;
	struct atp_block atpb;
	int lkupatmps, mess_length, name_length;
	char *username = whoami();
	char *type = "Broadcast";
	/* char *zone = "*"; */

	/* The data here is the "User Data" portion of the ATP header.
	   This appeared to be the same on every message sent, so we just
	   pack it in.  */
	unsigned char textbuf[512] = { 0x43, 0xfc, 0x55, 0xfb };

	/* This is so we can do looks-ups and get addresses and stuff */
	struct nbpnve nn;

	/* Look up the name, we'll give it four tries. */
	for (lkupatmps = 4; lkupatmps > 0; lkupatmps--)
	{
		if (nbp_lookup(obj, type, zone, &nn, 1) <= 0)
		{
			if( errno != 0 )
			{
				/* We Will in the future do more robust
				   error handling, but as EOH is approaching,
				   we don't */
				perror("nbp_lookup");
				/* exit(2); */
				return;
			}
			fprintf(stderr, "Name lookup failure for %s@%s\n", obj, zone);
		}
		else
		{
			break;
		}
	}
	if (lkupatmps == 0)
	{
		fprintf(stderr, "Could not find %s@%s in ten tries\n", obj, zone);
		/* exit(2); */
		return;
	}

	/* Open the appletalk socket */
        if ((latp = atp_open(0)) == NULL)
	/* if ((latp = atp_open(atp->atph_saddr.sat_port)) == NULL) */
	{
		perror("atp_open");
		/* exit(2); */
		return;
	}
        
	mess_length = strlen(message);
	name_length = strlen(username);
	textbuf[4] = mess_length + name_length + 1;

	/* space_for_message = 255 - name_length - 1 */
	if (mess_length > (255 - name_length - 1))
		mess_length = 255 - name_length - 1;

	strncpy(&(textbuf[5]), message, mess_length);
	textbuf[mess_length + 5] = 0xd1;
	strcpy(&(textbuf[mess_length + 6]), username);

	/* Copy the icon to the end of the string so we have one */
	memcpy ( &(textbuf[260]),icons[icon_no], 128);

	if(!memcmp(icons[icon_no], &(textbuf[260]), 128)){
		fprintf(stderr,"HOSER!\n");
	}
	atpb.atp_saddr = &nn.nn_sat;
	atpb.atp_sreqdata = textbuf;
	atpb.atp_sreqdlen = SEND_LENGTH;	/* With Icon */
	atpb.atp_sreqto = 2;
	atpb.atp_sreqtries = 3;
	if (atp_sreq(latp, &atpb, 1, ATP_XO) < 0) {
		fprintf(stderr,"FUCK\n");
		perror("atp_sreq");
		/* exit(1); */
		atp_close(latp);
		return;
	}
	if(!memcmp(icons[icon_no], &(textbuf[260]), 128)){
		fprintf(stderr,"HOSER2!\n");
	}

	atp_close(latp);
}

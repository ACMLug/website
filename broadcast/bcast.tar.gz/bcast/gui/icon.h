enum icon { LINUX, MAIL, APPLE, PRINTER, MAC, CLOCK, BIKE, AMBLIENCE, WHY,
	    DISK, BOMB, FILESERVER, PHONE, BUTT };

extern const char icon_names[][11];

extern const char icons[][256];

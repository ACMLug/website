#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netdb.h>
#include <stdio.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/zip.h>
#include "getzones.h"

void getzones(char* zones[], int *total_zones)
{
    struct atp_handle	*ah;
    struct atp_block	atpb;
    struct sockaddr_at	saddr;
    struct servent	*se;
    char		reqdata[4], buf[ ATP_MAXDATA ];
    struct iovec	iov;
    short		temp, index = 0;
    int			c, myzoneflg = 0, localzonesflg = 0, errflg = 0;
    extern int		optind;

    reqdata[ 0 ] = ZIPOP_GETZONELIST;

    if (( ah = atp_open( 0 )) == NULL ) {
	perror( "atp_open" );
	exit( 1 );
    }

    bzero( (char *) &saddr, sizeof( struct sockaddr_at ));
    saddr.sat_family = AF_APPLETALK;
    if (( se = getservbyname( "zip", "ddp" )) == NULL ) {
	fprintf( stderr, "Unknown service.\n" );
	exit( 1 );
    }
    saddr.sat_port = ntohs( se->s_port );

    saddr.sat_addr.s_net = ATADDR_ANYNET;
    saddr.sat_addr.s_node = ATADDR_ANYNODE;

    index = 1;
    reqdata[1] = 0;

    do {
	atpb.atp_saddr = &saddr;
	temp = htons( index );
	bcopy( &temp, &reqdata[2], 2 );
	atpb.atp_sreqdata = reqdata;
	atpb.atp_sreqdlen = 4;
	atpb.atp_sreqto = 2;
	atpb.atp_sreqtries = 5;

	/* send getzone request zones (or get my zone)
	*/
	if ( atp_sreq( ah, &atpb, 1, 0 ) < 0 ) {
	    perror( "atp_sreq" );
	    exit( 1 );
	}

	iov.iov_base = buf;
	iov.iov_len = ATP_MAXDATA;
	atpb.atp_rresiov = &iov;
	atpb.atp_rresiovcnt = 1;

	if ( atp_rresp( ah, &atpb ) < 0 ) {
	    perror( "atp_rresp" );
	    exit( 1 );
	}

	bcopy( &((char *)iov.iov_base)[2], &temp, 2 );
	temp = ntohs( temp );
	store_zones( temp, iov.iov_base+4, total_zones, zones );
	index += temp;
    } while (!((char *)iov.iov_base)[ 0 ] );

    if ( atp_close( ah ) != 0 ) {
	perror( "atp_close" );
	exit( 1 );
    }
}


void store_zones( n, buf, total_zones, zones )
    short	n;		/* number of zones in this packet */
    char	*buf;		/* zone length/name pairs */
    int		*total_zones;	/* Total number of zones */
    char*	zones[];		/* What do you think? */
{
	int number;

	/* printf("In print_zones %d\n", count++); */

    for ( ; n--; buf += (*buf) + 1 ) {
	number = (int) *buf;
	zones[*total_zones] = malloc(number + 1);
	strncpy(zones[*total_zones], buf+1, number);
	zones[*total_zones][number] = '\0';
	(*total_zones)++;

	/* printf( "%.*s\n", *buf, buf+1 ); */
    }
}

void printz(char* zones[], int total_zones) {

	while(total_zones) 
		printf("%s\n", zones[--total_zones]);
}


	
/* void main() {
	int total_zones = 0;
	char* zones[MAX_ZONES];

	getzones(zones, &total_zones);
	printz(zones, total_zones);
}*/

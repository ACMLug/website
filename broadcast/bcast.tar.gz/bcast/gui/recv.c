#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <stdio.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>
#include <signal.h>
#include "getid.h"

#include "gui.h"

ATP atp;
struct atp_block atpb;
struct sockaddr_at sat;
char cbuf[388];
int length;
char *message, *delim;

char *Obj = NULL, Type[] = "Broadcast", Zone[] = "*";

int RecvInit(void)
{
	Obj = whoami();

	atp = atp_open(0);
	/* asp = asp_init(atp); */

	nbp_rgstr(atp_sockaddr(atp), Obj, Type, Zone);

	printf("%s:%s@%s started on %u.%u:%u\n", Obj, Type, Zone,
	       ntohs( atp_sockaddr( atp )->sat_addr.s_net),
		atp_sockaddr(atp)->sat_addr.s_node,
		atp_sockaddr(atp)->sat_port);

	bzero( &sat, sizeof( struct sockaddr_at));
	sat.sat_family = AF_APPLETALK;
	sat.sat_addr.s_net = ATADDR_ANYNET;
	sat.sat_addr.s_node = ATADDR_ANYNODE;
	sat.sat_port = ATADDR_ANYPORT;

	atpb.atp_saddr = &sat;
	atpb.atp_rreqdata = cbuf;
	atpb.atp_rreqdlen = sizeof(cbuf);

        return atp->atph_socket;       
}

void RecvIO(void)
{
	char rbuf[21];
	struct iovec iov;
    
	fprintf(stderr, "About to try and stuff\n");
	if (atp_rreq(atp, &atpb) < 0) {
		fprintf(stderr, "Something fucked up.");
	}

	fprintf(stderr, "This is length shit %d\n", *(cbuf + 4));

	/* the first 4 are the user data, adn we can ignore that again */	
	length = (int) *(cbuf + 4);
	delim = index(cbuf, 0xd1);
	cbuf[delim - cbuf] = '\0';
	cbuf[length+5]= '\0';
        cbuf[259] = '\0';

/*	fprintf(stderr, "%s had this to say: %s\n", delim + 1, cbuf +5);*/

        MessageBox(cbuf+5,delim+1,&(cbuf[260]),atpb);

            /* We need to do an atp_rresp() */
        rbuf[0] = 0;
        rbuf[1] = 0;
        rbuf[2] = 0;
        rbuf[3] = 0;
        rbuf[4] = 0xaf;
        rbuf[5] = 0x4d;
        rbuf[6] = 0xef;
        rbuf[7] = 0xe0;

        iov.iov_base = rbuf;
        iov.iov_len = sizeof(rbuf);

        atpb.atp_rresiov = &iov;
        atpb.atp_rresiovcnt = 1;

	atp_sresp(atp, &atpb);
    
   	atpb.atp_saddr = &sat;
	atpb.atp_rreqdata = cbuf;
	atpb.atp_rreqdlen = sizeof(cbuf);

}

void RecvDeInit(void)
{
    
	nbp_unrgstr(Obj, Type, Zone);
}


int lkup_init(void);
int StartQuery(char *, struct nbpnve, int, int);
int LexSend(void);
int MoreData(void);

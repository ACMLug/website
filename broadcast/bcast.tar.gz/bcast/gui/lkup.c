#include <stdio.h>
#include <sys/types.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/signal.h>
#include <sys/time.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/nbp.h>
#include <atalk/ddp.h>

#include <netdb.h>

#define BCASTON 1
extern int errno;
static char             nbp_send[ 1024 ];
static char             nbp_recv[ 1024 ];
static u_char           nbp_port = 0;


static struct sockaddr_at addr;
static struct itimerval it, oit;
static struct sigaction sv, osv;
static struct nbpnve nve;
static struct nbphdr nh;
static struct nbptuple nt;
static struct servent *se;
static char *data;
static int s, namelen, cnt, tries, sc, cc, i;

static char *obj, *type, *zone;
static struct nbpnve *nn;
static int nncnt;

/* ============================================== */

int lkup_init() {

    if (( s = socket( AF_APPLETALK, SOCK_DGRAM, 0 )) < 0 ) {
	return( -1 );
    }

    bzero( &addr, sizeof( struct sockaddr_at ));
    addr.sat_family = AF_APPLETALK;
    addr.sat_addr.s_net = ATADDR_ANYNET;
    addr.sat_addr.s_node = ATADDR_ANYNODE;
    addr.sat_port = ATADDR_ANYPORT;
    if ( bind( s, (struct  sockaddr  *)&addr, 
	       sizeof( struct sockaddr_at )) < 0 ) {
	return( -1 );
    }
 
    return s; 
}

/* ============================================== */

int StartQuery(char *zone, struct nbpnve *nn0, int nncnt, int OnOff) {
/* int StartQuery(char *fuck, struct nbpnve *nn0, int nncnt, int OnOff) { */

  const char *obj = "=";
  char type[11];
  /* char *zone = "*"; */

  nn = nn0;
 
  if (OnOff == BCASTON) 
    strcpy(type, "BroadCast");
  else 
    strcpy(type, "-BroadCast");
  
  namelen = sizeof( struct sockaddr_at );
  if ( getsockname( s, &addr, &namelen ) < 0 ) {
    return( -1 );
  }
  
  data = nbp_send;
  *data++ = DDPTYPE_NBP;
  nh.nh_op = NBPOP_BRRQ;
  nh.nh_cnt = 1;
  nh.nh_id = 0;
  bcopy( &nh, data, SZ_NBPHDR );
  data += SZ_NBPHDR;
  
  nt.nt_net = addr.sat_addr.s_net;
  nt.nt_node = addr.sat_addr.s_node;
  nt.nt_port = addr.sat_port;
  bcopy( &nt, data, SZ_NBPTUPLE);
  data += SZ_NBPTUPLE;
  
    if ( obj ) {
      if (( cc = strlen( obj )) > NBPSTRLEN ) return( -1 );
      *data++ = cc;
      bcopy( obj, data, cc );
      data += cc;
    } else {
      *data++ = 0;
    }

    if ( type ) {
	if (( cc = strlen( type )) > NBPSTRLEN ) return( -1 );
	*data++ = cc;
	bcopy( type, data, cc );
	data += cc;
    } else {
	*data++ = 0;
    }
  if ( zone ) {
    if (( cc = strlen( zone )) > NBPSTRLEN ) return( -1 );
    *data++ = cc;
    bcopy( zone, data, cc );
    data += cc;
  } else {
    *data++ = 0;
  }
  
  bzero( &addr, sizeof( struct sockaddr_at ));
  addr.sat_family = AF_APPLETALK;
  addr.sat_addr.s_net = ATADDR_ANYNET;
  addr.sat_addr.s_node = ATADDR_ANYNODE;
  if ( nbp_port == 0 ) {
    if (( se = getservbyname( "nbp", "ddp" )) == NULL ) {
      nbp_port = 2;
    } else {
      nbp_port = ntohs( se->s_port );
    }
  }
  addr.sat_port = nbp_port;
}

/* ============================================== */

int LexSend() {
  
  cnt = 0;
  tries = 3;
  sc = data - nbp_send;

  if ( sendto( s, nbp_send, sc, 0, &addr, sizeof( struct sockaddr_at )) < 0 ) {
    return( -1 );
  }
}

/* ============================================= */

int MoreData() {
 
  if(( cc = recvfrom( s, nbp_recv, sizeof( nbp_recv ), 0, 0,
			  &namelen )) > 0 ) {
    data = nbp_recv;
    if ( *data++ != DDPTYPE_NBP ) {
      return cnt;
    }
    cc--;
    
    bcopy( data, &nh, SZ_NBPHDR );
    data += SZ_NBPHDR;
    if ( nh.nh_op != NBPOP_LKUPREPLY ) {
      return cnt;
    }
    cc -= SZ_NBPHDR;
      
    while (( i = nbp_parse( data, &nve, cc )) >= 0 ) {
      data += cc - i;
      cc = i;
      /*
       * Check to see if nve is already in nn. If not,
       * put it in, and increment cnt.
       */
      for ( i = 0; i < cnt; i++ ) {
	if ( nbp_match( &nve, &nn[ i ],
			NBPMATCH_NOZONE|NBPMATCH_NOGLOB )) {
	return cnt; }
      }
      if ( i == cnt ) {
	nn[ cnt++ ] = nve;
      }
      if ( cnt == nncnt ) {
	tries = 0;
	break;
      }
    }
    if ( cnt == nncnt ) {
      tries = 0;
      return cnt;
    }
  }
  tries--;



  errno = 0;
  return( cnt );
}





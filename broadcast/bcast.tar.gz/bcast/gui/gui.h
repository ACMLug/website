void SetHostList(char **items, int count);
void SetZoneList(char **items, int count);
void SetListenFunc(int fd, void (*func)(void));
void SetSendFunc(void (*func)(char *zone, char *host, char *msg, int icon));
void SetZoneFunc(void (*func)(char *zone));
void InitGUI(int argc, char **argv);
void RunGUI(void);
void MessageBox(char *msg, char *tagline, unsigned char *icon);




#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <stdio.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>

#include <X11/Xlib.h>

#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/Form.h>
#include <Xm/List.h>
#include <Xm/PushB.h>
#include <Xm/ScrolledW.h>
#include <Xm/Text.h>
#include <Xm/Frame.h>
#include <Xm/DrawnB.h>

#define KEITHSUCKS 12

#include "icon.h"

Pixmap pixmaps[KEITHSUCKS];

char *resources[] = {
    "*Foreground: black",
    "*Background: #bfbfbfbfbfbf",
    "*XmTextField*background: #909090",
    "*XmText*background: #909090",
    "*XmList*background: #909090",
    "*topOffset: 1",
    "*bottomOffset: 1",
    "*leftOffset: 1",
    "*rightOffset: 1",
    "*highlightThickness: 0",
    "*fontList: -*-helvetica-bold-r-normal-*-18-*-*-*-*-*-iso8859-1",
    NULL
};


char *foo[] = {
    "hagbard", "isengard", "shire", "imladris", "valinor", "porkchop",
    "osiris", "mordor", "enigma", "void", "sdgraid", "spam", "sleepless",
    "wilbur", "balin", "dwalin", "bifur", "bofur", "fajita"
};


Display *display;
int screen;

XtAppContext app;
Widget top, form, textfield;
Widget zonelist, hostlist;
char **zonestr = NULL, **hoststr = NULL;
int zoneitem, hostitem;
Widget opt[KEITHSUCKS];
void (*sendfunc)(char *zone, char *host, char *msg, int icon) = NULL;
void (*zonefunc)(char *zone) = NULL;


int sel_icon = 0;

void sel_cb(Widget w, XtPointer cli, XtPointer call)
{
    XtVaSetValues(opt[sel_icon],
                  XmNshadowType, XmSHADOW_OUT,
                  NULL);
    sel_icon = (int) cli;
    XtVaSetValues(opt[sel_icon],
                  XmNshadowType, XmSHADOW_IN,
                  NULL);    
}

#define ACT_QUIT 1
#define ACT_SEND 2
#define ACT_ZONE 3
#define ACT_HOST 4

void list_cb(Widget w, XtPointer cli, XtPointer call)
{
    XmListCallbackStruct *lcs = (XmListCallbackStruct *) call;
    if(!cli){
            /* zone */
        zoneitem = lcs->item_position-1;
        fprintf(stderr,"zone = %s\n",zonestr[zoneitem]);
        if(zonefunc) zonefunc(zonestr[zoneitem]);        
    } else {
        hostitem = lcs->item_position-1;        
    }
    
}


void RecvDeInit(void);

void act_cb(Widget w, XtPointer cli, XtPointer call)
{
    char *msg;
    
    switch((int) cli){
    case ACT_QUIT :
        RecvDeInit();        
        exit(0);

    case ACT_SEND :
        msg = XmTextGetString(textfield);            
        fprintf(stderr,"SEND: zone = \"%s\", host = \"%s\", "
                "msg = \"%s\", icon = %d\n",
                zonestr ? zonestr[zoneitem] : "*NULL*",
                hoststr ? hoststr[hostitem] : "*NULL*",
                msg,sel_icon);
        if(zonestr && hoststr && sendfunc){
            sendfunc(zonestr[zoneitem],hoststr[hostitem],msg,sel_icon);
		XmTextSetString(textfield,"");
        }        
        free(msg);            
        break;

    case ACT_ZONE :
        break;

    case ACT_HOST :
        
        break;        
    }
}


void ReadIcons(void)
{
    int i,j,k;
    unsigned char bitmap[128];
    

    for(i=0;i<KEITHSUCKS;i++){
        for(j=0;j<128;j++){
            bitmap[j]=0;
            for(k=0;k<8;k++){
                bitmap[j] |= ((icons[i][j] & (1<<k)) >> k) << (7-k);                
            }            
        }
        
        pixmaps[i] = XCreatePixmapFromBitmapData(display, XtWindow(top),
                                                 bitmap,
                                                 32, 32,
                                                 WhitePixel(display,screen),
                                                 BlackPixel(display,screen),
                                                 1);
        if(!pixmaps[i]){
            fprintf(stderr,"cannot convert %s\n",icon_names[i]);
            exit(1);
        }
    }    
}

void SetList(Widget list, char **items, int count)
{
    int i;
    XmStringTable table;

    table = (XmStringTable) XtMalloc(count * sizeof(XmString *));
    for(i=0;i<count;i++){
        table[i] = XmStringCreateLocalized(items[i]);
    }
    XtVaSetValues(list,
                  XmNitemCount, count,
                  XmNitems, table,
                  NULL);
    for(i=0;i<count;i++){
        XmStringFree(table[i]);
    }
    XtFree(table);    
}


void SetListenFunc(int fd, void (*func)(void))
{
    XtAppAddInput(app,fd,XtInputReadMask,func,NULL);    
}

void SetSendFunc(void (*func)(char *zone, char *host, char *msg, int icon))
{
    sendfunc = func;    
}

void SetZoneFunc(void (*func)(char *zone))
{
    zonefunc = func;
}


void SetZoneList(char **items, int count)
{
    SetList(zonelist, items, count);
    zonestr = items;    
}
void SetHostList(char **items, int count)
{
    SetList(hostlist, items, count);
    hoststr = items;    
}

void RunGUI(void)
{
    XtAppMainLoop(app);    
}

typedef struct 
{
    Widget box;
    Pixmap icon;
} box;

void msg_cb(Widget w, XtPointer cli, XtPointer call) 
{
    box *thebox = (box *) cli;
    XtDestroyWidget(thebox->box);
    if(thebox->icon) XFreePixmap(display,thebox->icon);
}

void MessageBox(char *msg, char *tagline, unsigned char *icon, struct atp_block atpb)
{
    int i,j,k;
    unsigned char bitmap[128];
    box *newbox = (box *) malloc(sizeof(box));
    Widget win, form, w, x;

    for(j=0;j<128;j++){
        bitmap[j]=0;
        for(k=0;k<8;k++){
            bitmap[j] |= ((icon[j] & (1<<k)) >> k) << (7-k);                
        }            
    }

    newbox->box = win = XtVaCreatePopupShell("Message for you sir!",
                                             topLevelShellWidgetClass,
                                             top,
                                             XmNwidth, 415,
                                             XmNheight, 200,
                                             NULL);
    
    newbox->icon = XCreatePixmapFromBitmapData(display, XtWindow(top),
                                               bitmap,
                                               32, 32,
                                               WhitePixel(display,screen),
                                               BlackPixel(display,screen),
                                              1);

    form = XtVaCreateManagedWidget("form", xmFormWidgetClass, win,
                                   XmNfractionBase, 10,
                                   NULL);

    w = XtVaCreateManagedWidget("OK",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 8,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 8,
                                XmNrightPosition, 10,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);                            

    x = XtVaCreateManagedWidget("Answer",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 8,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 6,
                                XmNrightPosition, 8,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);                            

    XtAddCallback(w, XmNactivateCallback, msg_cb, (void *) newbox);
    if(newbox->icon)
        XtVaCreateManagedWidget(" ",
                                xmLabelWidgetClass,form,
                                XmNlabelType, XmPIXMAP,
                                XmNlabelPixmap, newbox->icon,
                                XmNtopPosition, 1,
                                XmNbottomPosition, 7,
                                XmNleftPosition, 0,
                                XmNrightPosition, 2,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
   
    XtVaCreateManagedWidget(tagline,
                            xmLabelWidgetClass,form,
                            XmNtopPosition, 8,
                            XmNbottomPosition, 10,
                            XmNleftPosition, 0,
                            XmNrightPosition, 7,
                            XmNtopAttachment, XmATTACH_POSITION,
                            XmNbottomAttachment, XmATTACH_POSITION,
                            XmNleftAttachment, XmATTACH_POSITION,
                            XmNrightAttachment, XmATTACH_POSITION,
                            XmNalignment, XmALIGNMENT_BEGINNING,
                            NULL);
    w=  XtVaCreateManagedWidget(" ",
                                xmTextWidgetClass,form,
                                XmNtopPosition, 1,
                                XmNbottomPosition, 7,
                                XmNleftPosition, 2,
                                XmNrightPosition, 9,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                XmNeditable, False,
                                XmNwordWrap, True,
                                XmNeditMode, XmMULTI_LINE_EDIT,
                            NULL);
    XmTextSetString(w,msg);
    
    XtPopup(win,XtGrabNone);
}


void InitGUI(int argc, char **argv)
{
    int i;
    Widget w;
    
    top = XtVaAppInitialize(&app,"BroadCast/Linux",NULL,0,
                            &argc,argv,
                            resources,
                            XmNwidth, 750,
                            XmNheight, 400,
                            NULL);

    display = XtDisplay(top);
    screen = XScreenNumberOfScreen(XtScreen(top));
    
    form = XtVaCreateManagedWidget("form", xmFormWidgetClass, top,
                                   XmNfractionBase, 10,
                                   NULL);

    
    w = XtVaCreateManagedWidget("Zone",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 9,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 0,
                                XmNrightPosition, 2,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);                            
    XtAddCallback(w, XmNactivateCallback, act_cb, (void *) ACT_ZONE);
    w = XtVaCreateManagedWidget("Host",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 9,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 2,
                                XmNrightPosition, 4,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
    XtAddCallback(w, XmNactivateCallback, act_cb, (void *) ACT_HOST);

    w = XtVaCreateManagedWidget("scroller",xmScrolledWindowWidgetClass,form,
                                XmNscrollingPolicy, XmAPPLICATION_DEFINED,
                                XmNtopPosition, 0,
                                XmNbottomPosition, 9,
                                XmNleftPosition, 0,
                                XmNrightPosition, 2,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
    zonelist = XtVaCreateManagedWidget("zonelist", xmListWidgetClass, w,
                                       XmNselectionPolicy, XmSINGLE_SELECT,
                                       NULL);
    XtAddCallback(zonelist, XmNsingleSelectionCallback, list_cb, NULL);
    
    w = XtVaCreateManagedWidget("scroller",xmScrolledWindowWidgetClass,form,
                                XmNscrollingPolicy, XmAPPLICATION_DEFINED,
                                XmNtopPosition, 0,
                                XmNbottomPosition, 9,
                                XmNleftPosition, 2,
                                XmNrightPosition, 4,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
    hostlist = XtVaCreateManagedWidget("hostlist", xmListWidgetClass, w,
                                       XmNselectionPolicy, XmSINGLE_SELECT,
                                       NULL);
    XtAddCallback(hostlist, XmNsingleSelectionCallback, list_cb, (void *) 1);

    /* SetList(zonelist,foo,19);
    zonestr = foo;
    */
        
    w = XtVaCreateManagedWidget("Send",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 9,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 4,
                                XmNrightPosition, 8,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
    XtAddCallback(w, XmNactivateCallback, act_cb, (void *) ACT_SEND);
    w = XtVaCreateManagedWidget("Quit",xmPushButtonWidgetClass,form,
                                XmNtopPosition, 9,
                                XmNbottomPosition, 10,
                                XmNleftPosition, 8,
                                XmNrightPosition, 10,
                                XmNtopAttachment, XmATTACH_POSITION,
                                XmNbottomAttachment, XmATTACH_POSITION,
                                XmNleftAttachment, XmATTACH_POSITION,
                                XmNrightAttachment, XmATTACH_POSITION,
                                NULL);
    XtAddCallback(w, XmNactivateCallback, act_cb, (void *) ACT_QUIT);
    XtVaCreateManagedWidget("Linux BroadCast v0.3",
                            xmLabelWidgetClass,form,
                            XmNtopPosition, 0,
                            XmNbottomPosition, 1,
                            XmNleftPosition, 4,
                            XmNrightPosition, 10,
                            XmNtopAttachment, XmATTACH_POSITION,
                            XmNbottomAttachment, XmATTACH_POSITION,
                            XmNleftAttachment, XmATTACH_POSITION,
                            XmNrightAttachment, XmATTACH_POSITION,
                            NULL);
    for(i=0;i<KEITHSUCKS;i++){
        
    opt[i] = XtVaCreateManagedWidget(" ",
                                     xmDrawnButtonWidgetClass,form,
                                     XmNlabelType, XmPIXMAP,
                                     XmNshadowType,
                                     i == sel_icon ? XmSHADOW_IN:XmSHADOW_OUT,
                                     XmNtopPosition, 1+2*(i/6),
                                     XmNbottomPosition, 3+2*(i/6),
                                     XmNleftPosition, 4+i%6,
                                     XmNrightPosition, 5+i%6,
                                     XmNtopAttachment, XmATTACH_POSITION,
                                     XmNbottomAttachment, XmATTACH_POSITION,
                                     XmNleftAttachment, XmATTACH_POSITION,
                                     XmNrightAttachment, XmATTACH_POSITION,
                                     NULL);
    XtAddCallback(opt[i],XmNarmCallback, sel_cb, (void *) i);
    }
    
    
    XtVaCreateManagedWidget("Enter your message here:",
                            xmLabelWidgetClass,form,
                            XmNtopPosition, 5,
                            XmNbottomPosition, 6,
                            XmNleftPosition, 4,
                            XmNrightPosition, 10,
                            XmNtopAttachment, XmATTACH_POSITION,
                            XmNbottomAttachment, XmATTACH_POSITION,
                            XmNleftAttachment, XmATTACH_POSITION,
                            XmNrightAttachment, XmATTACH_POSITION,
                            NULL);
    textfield = XtVaCreateManagedWidget("foo",
                            xmTextWidgetClass,form,
                            XmNeditMode, XmMULTI_LINE_EDIT,
                            XmNtopPosition, 6,
                            XmNbottomPosition, 9,
                            XmNleftPosition, 4,
                            XmNrightPosition, 10,
                            XmNtopAttachment, XmATTACH_POSITION,
                            XmNbottomAttachment, XmATTACH_POSITION,
                            XmNleftAttachment, XmATTACH_POSITION,
                            XmNrightAttachment, XmATTACH_POSITION,
                            NULL);


    XtRealizeWidget(top);
    XFlush(display);
    ReadIcons();    
    for(i=0;i<KEITHSUCKS;i++) {
        XtVaSetValues(opt[i],
                      XmNlabelPixmap, pixmaps[i],
                      NULL);
    }
    
    
}




/* int main(int argc, char *argv[])
{
    InitGUI(argc,argv);
    RunGUI();    
} */

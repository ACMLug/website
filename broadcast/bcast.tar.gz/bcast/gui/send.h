void send_bcast(char *zone, char *obj, char *message, int icon_no);

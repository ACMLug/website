/* Read a text file that contains the hex data for a Mac 32x32x1 icon and 
   display it with the bitmap console display functions. It expects the 
   filename as the only argument. */

/* Most of this code is by Tony Stuckey */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

void main(int argc, char **argv) {
  
  char char1[3];
  int fd, charnum;
  
  int counter = 0;
  char bitmap[256];
  
  
  if (argc < 2) /* no command line args */
    printf("missing filename!\n");
  else { 
    /* open the specified file */
    fd=open(argv[1],O_RDONLY,"+r");

    /* read input while there is input to read */
    while (read(fd , char1 ,2) > 0)
      {
	/* Jason needs to find out what's going on here */
	char1[2] = '\0';

	sscanf(char1,"%x",&charnum);

	printf("%d, ", charnum);
	/* store each char in bitmap[counter] */
	bitmap[counter] = charnum;
	++counter;
      }
  }
}


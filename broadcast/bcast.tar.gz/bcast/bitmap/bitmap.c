/* Bitmap Console Display */
/* lug@uiuc.edu */

/* Most of this code is by Jason Luther with a lot of help from Tony Stuckey
   and Paul Watts */

#include <stdio.h>

#define UPPER ((32*32)/8) /* how many characters are in the array */
#define WORDPERLINE (4) /* number of chars per line */ 

/* print_from_char disassembles the chars and prints out the actual characters.
   Hooray! */

void print_from_char(char werd) {

  int counter = 0;
  
  /* iterate through each of the 8 bits per character */
  for (counter = 0; counter < 8; counter++) {
    /* flips character around and checks for ON or OFF. */
    ((werd & 0x80) == 0) ? printf(" ") : printf("*");
    /* shift the bits in werd over one position */
    werd = werd << 0x1;
  }
}

/* print_bitmap takes the pointer to the character array containing the bitmap
   and prints it out with the help of print_from_char(). */

void print_bitmap(char *bitmap) {
  
  int counter = 0;
  
  /* do this for 128 characters */
  while (counter < UPPER) 
    {
      /* call print_from_char() with each of the chars in the array */
      print_from_char(bitmap[counter++]);
      /* print a newline after every four chars (32 bits) */
      if (counter % WORDPERLINE == 0)
	printf("\n");
    }
}

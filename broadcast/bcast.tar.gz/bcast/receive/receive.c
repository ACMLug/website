#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <stdio.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>
#include <signal.h>
#include "../gui/getid.h"

void Keith() {
	printf("whee\n");
}

void main() {

	ATP atp;
	struct atp_block atpb;
	struct sockaddr_at sat;
	char cbuf[1024];
	int length;
	char *message, *delim;
	struct iovec iov;
	char rbuf[21];
	
	char *Obj = NULL, Type[] = "Broadcast", Zone[] = "*";

	Obj = whoami();

	signal(SIGUSR1, Keith);

	atp = atp_open(0);
	/* asp = asp_init(atp); */

	nbp_rgstr(atp_sockaddr(atp), Obj, Type, Zone);

	printf("%s:%s@%s started on %u.%u:%u\n", Obj, Type, Zone,
	       ntohs( atp_sockaddr( atp )->sat_addr.s_net),
		atp_sockaddr(atp)->sat_addr.s_node,
		atp_sockaddr(atp)->sat_port);

	bzero( &sat, sizeof( struct sockaddr_at));
	sat.sat_family = AF_APPLETALK;
	sat.sat_addr.s_net = ATADDR_ANYNET;
	sat.sat_addr.s_node = ATADDR_ANYNODE;
	sat.sat_port = ATADDR_ANYPORT;

	atpb.atp_saddr = &sat;
	atpb.atp_rreqdata = cbuf;
	atpb.atp_rreqdlen = sizeof(cbuf);

	fprintf(stderr, "atpb has the value %u.%u:%u\n",
		ntohs(atpb.atp_saddr->sat_addr.s_net),
		atpb.atp_saddr->sat_addr.s_node,
		atpb.atp_saddr->sat_port);

	fprintf(stderr, "About to try and stuff\n");
	if (atp_rreq(atp, &atpb) < 0) {
		fprintf(stderr, "Something fucked up.");
	}

	/* atpb.atp_saddr->sat_port -= 1; */
	fprintf(stderr, "atpb has the value %u.%u:%u\n",
		ntohs(atpb.atp_saddr->sat_addr.s_net),
		atpb.atp_saddr->sat_addr.s_node,
		atpb.atp_saddr->sat_port);
		
	fprintf(stderr, "This is length shit %d\n", *(cbuf + 4));

	/* the first 4 are the user data, adn we can ignore that again */	
	length = (int) *(cbuf + 4);
	delim = index(cbuf, 0xd1);
	cbuf[delim - cbuf] = '\0';
	cbuf[length+5]= '\0';

	fprintf(stderr, "%s had this to say: %s\n", delim + 1, cbuf + 5);

	print_bitmap(&(cbuf[260]));

	rbuf[0] = 0;
	rbuf[1] = 0;
	rbuf[2] = 0;
	rbuf[3] = 0;
	rbuf[4] = 0xaf;
	rbuf[5] = 0x4d;
	rbuf[6] = 0xef;
	rbuf[7] = 0xe0;

/*	atpb.atp_rreqdlen = sizeof(68); 
*/
	/* atpb.atp_data.rresdata.atpd_iov = &keith; */
	/* atpb.atp_data.rresdata.atpd_iovcnt = 0; */

	/* atp_sresp(atp, &atpb); */
	/* atp_rresp(atp, &atpb, 1, ATP_EOM); */
	iov.iov_base = rbuf;
	iov.iov_len = sizeof(rbuf);

	atpb.atp_rresiov = &iov;
	atpb.atp_rresiovcnt = 1;

	atp_sresp(atp, &atpb);
	/* atp_sreq(atp, &atpb, 1, ATP_EOM); */

	nbp_unrgstr(Obj, Type, Zone);
}

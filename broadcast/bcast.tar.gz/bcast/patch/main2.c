#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gui.h"
#include "send.h"
#include "getzones.h"

#include "recv.h"

void dosort(char **zones, int c)
{
	char *t;
	int i,f;
	do {
	f = 0;
		for(i=0;i<c-1;i++){
			if(strcmp(zones[i],zones[i+1])>0){
				t = zones[i];
				zones[i] = zones[i+1];
				zones[i+1] = t;
				f = 1;
			}
		}
	} while (f);

}

struct nbpnve nns[100];
char *hosts[100];
int hcount = 0;

void zoneFunc(char *zone) {
	hcount = 0;
	SetHostList(hosts,0);
	StartQuery(zone, nns, 100, 1);
	LexSend();
}


void LISTEN(void) {
	int i;
	if(hcount = MoreData()){
	for(i=0;i<hcount;i++){
		memcpy(hosts[i],nns[i].nn_obj,nns[i].nn_objlen);
		hosts[i][nns[i].nn_objlen]=0;
	}
	SetHostList(hosts,hcount);
	}
}

int main(int argc, char *argv[]) {

	/* char* zones[300]; */
	/* int no_zones = 0; */
	char* zones[1] = { "*" };
	int no_zones = 1;
	int i;
	int s,s2;

        s = lkup_init();

	for (i=0;i<100;i++) hosts[i] = malloc(33);
	getzones(zones, &no_zones);

        s2 = RecvInit();
	InitGUI(argc, argv);
        
	SetListenFunc(s, LISTEN);
	SetListenFunc(s2, RecvIO);
	SetZoneFunc(zoneFunc);
        dosort(zones, no_zones);

	SetZoneList(zones, no_zones);
	SetSendFunc(send_bcast);
	RunGUI();
}

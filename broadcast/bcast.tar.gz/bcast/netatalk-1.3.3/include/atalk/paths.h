/*
 * papd paths
 */
#define _PATH_PAPDPRINTCAP	"/etc/printcap"
#define _PATH_PAPDSPOOLDIR	"/usr/spool/lpd"
#define _PATH_DEVPRINTER	"/dev/printer"

/*
 * atalkd paths
 */
#define _PATH_ATALKDEBUG	"/tmp/atalkd.debug"
#define _PATH_ATALKDTMP		"atalkd.tmp"

/*
 * psorder paths
 */
#define _PATH_TMPPAGEORDER	"/tmp/psorderXXXXXX"

/*
 * afpd paths
 */
#define _PATH_AFPTKT		"/tmp/AFPtktXXXXXX"

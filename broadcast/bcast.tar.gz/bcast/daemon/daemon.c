/* Jason's Happy Daemon that keeps control of your teminal. */

#include <stdio.h>
#include <signal.h>
#include <sys/param.h>
#include <errno.h>
extern int errno;
#ifdef SIGTSTP
#include <sys/file.h>
#include <sys/ioctl.h>
#endif

int terminated = 1;

void test_funk() {
  terminated = 0;
}

void fake_message() {
  fprintf(stdout,"\nNew message from jluther@RSC_ISR:\n");
  fprintf(stdout,"This is a fake message. \n");
}

int server_mode() {

  int childpid;

  /* fork and exit parent. */
  if ((childpid = fork()) < 0)
    fprintf(stderr,"Can't fork the first child.\n");
  else if (childpid > 0)
    exit(0); /* the parent exits. */
  
  signal(SIGUSR1, test_funk);
  signal(SIGUSR2, fake_message);

  printf("BroadCast is waiting for messages.\n");

  pause(); 

  return 0;
}



int server_mode();
int main() {
  server_mode();
  return 0;
}

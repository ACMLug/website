#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>
#include <signal.h>

void main(int argc, char **argv) {

	int sock;
	struct sockaddr_at sin_addr;
	struct nbpnve nn;
	int lkupatmps;
	short port;
	short addr;
	char *obj = NULL, *type = NULL, *zone = NULL;
        char *name = "Server:-BroadCast@*";

        if (argc != 2) {
                fprintf(stderr, "Usage: %s obj:type@zone\n", argv[0]);
                exit(0);
        }

        if (nbp_name(name, &obj, &type, &zone) < 0) {
                fprintf(stderr, "%s -- Bad name\n", name);
                exit(1);
        }

        for (lkupatmps = 10; lkupatmps > 0; lkupatmps--) {
                if (nbp_lookup(obj, type, zone, &nn, 1) <= 0) {
                        if( errno != 0 ) {
                                perror("nbp_lookup");
                                exit(2);
                        }
                        fprintf(stderr, "Name lookup failure for %s\n", name);
                }
                else
                        break;
        }

       if (lkupatmps == 0) {
                fprintf(stderr, "Could not find %s in ten tries\n", name);
                exit(2);
        }

	/* if((sock = socket(AF_APPLETALK, SOCK_RDM, ATPROTO_DDP)) < 0) { */
	if((sock = socket(AF_APPLETALK, SOCK_DGRAM, ATPROTO_DDP)) < 0) {
		perror("Error opening Appletalk Socket");
		exit(1);
	}

	port = ntohs(nn.nn_sat.sat_port);

	sin_addr.sat_family = AF_APPLETALK;
	sin_addr.sat_port = htons(port);
/* Keith here*/
	bcopy(nn.nn_sat.sat_addr, sin_addr.sat_addr ;

	if (bind(sock, (struct sockaddr *)&sin_addr, sizeof(struct sockaddr_at)) < 0) {
		perror("error binding the socket");
		exit(1);
	}
}

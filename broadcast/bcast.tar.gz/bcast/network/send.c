#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <netatalk/endian.h>
#include <netatalk/at.h>
#include <atalk/atp.h>
#include <atalk/nbp.h>
#include <string.h>
#include <signal.h>
/* #include "bcast_funcs.h" */
#include "icon.h"

#define SEND_LENGTH 388

void main(int argc, char **argv)
{
	extern int errno;
	ATP atp;
	struct atp_block atpb;
	int lkupatmps, icon_number, mess_length, name_length;
	struct iovec iov;
	char rbuf[ATP_MAXDATA];
	char *username = whoami();

	/* The data here is the "User Data" portion of the ATP header.
	   This appeared to be the same on every message sent, so we just
	   pack it in.  */
	char textbuf[384] = { 0x43, 0xfc, 0x55, 0xfb };

	/* This is so we can do looks-ups and get addresses and stuff */
	struct nbpnve nn;

	/* all used for hostname look ups and what not */
	char *obj = NULL, *type = NULL, *zone = NULL;
	char *name = NULL;

	/* For this test send program, if we don't have the right amount
	   of data we barf out and tell them how to use it. */
	if (argc != 4) {
		int i;

		fprintf(stderr,
			"Usage: %s obj:type@zone <icon number> <message>\n",
			argv[0]);
		fprintf(stderr, "Icon number\tIcon name\n");
		for (i = 0; i <= PHONE; i++) {
			fprintf(stderr, "%d\t\t%s\n", i, icon_names[i]);
		}
		exit(0);
	}

	/* Lets find the icon and see if it is worthy */
	icon_number = atoi(argv[2]);
	if (icon_number < 0 && icon_number > 13) {
		fprintf(stderr, "You picked a bad icon!\n");
		exit(2);
	}
	printf("Using icon %s\n", icon_names[icon_number]);

	/* Get the name, and see if it is a valid Appletalk name */
	name = argv[1];
	if (nbp_name(name, &obj, &type, &zone) < 0)
	{
		fprintf(stderr, "%s -- Bad name\n", name);
		exit(1);
	}

	/* Look up the name, we'll give it four tries. */
	for (lkupatmps = 4; lkupatmps > 0; lkupatmps--)
	{
		if (nbp_lookup(obj, type, zone, &nn, 1) <= 0)
		{
			if( errno != 0 )
			{
				perror("nbp_lookup");
				exit(2);
			}
			fprintf(stderr, "Name lookup failure for %s\n", name);
		}
		else
		{
			break;
		}
	}
	if (lkupatmps == 0)
	{
		fprintf(stderr, "Could not find %s in ten tries\n", name);
		exit(2);
	}
	printf("Found %s at %u.%d:%d...\n", name,
		ntohs(nn.nn_sat.sat_addr.s_net),
		nn.nn_sat.sat_addr.s_node, nn.nn_sat.sat_port);

	/* Open the appletalk socket */
	if ((atp = atp_open(0)) == NULL)
	{
		perror("atp_open");
		exit(2);
	}

	mess_length = strlen(argv[3]);
	name_length = strlen(username);
	textbuf[4] = mess_length + name_length + 1;

	/* space_for_message = 255 - name_length - 1 */
	if (mess_length > (255 - name_length - 1))
		mess_length = 255 - name_length - 1;

	strncpy(&(textbuf[5]), argv[3], mess_length);
	textbuf[mess_length + 5] = 0xd1;
	strcpy(&(textbuf[mess_length + 6]), username);

	/* Copy the icon to the end of the string so we have one */
	bcopy (icons[icon_number], &(textbuf[260]), 128);

	atpb.atp_saddr = &nn.nn_sat;
	atpb.atp_sreqdata = textbuf;
	atpb.atp_sreqdlen = SEND_LENGTH;	/* With Icon */
	atpb.atp_sreqto = 3;
	atpb.atp_sreqtries = 6;
	if (atp_sreq(atp, &atpb, 1, ATP_XO) < 0) {
		perror("atp_sreq");
		exit(1);
	}


	iov.iov_base = rbuf;
	iov.iov_len = sizeof(rbuf);

	atpb.atp_rresiov = &iov;
	atpb.atp_rresiovcnt = 1;
	if (atp_rresp(atp, &atpb) < 0) {
		perror("atp_rresp");
	}

	/* nbp_rgstr(&atp->atph_saddr, obj, type, zone); */
	/* nbp_unrgstr(obj, type, zone); */

	atp_close(atp);
}
